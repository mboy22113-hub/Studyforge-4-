// src/middleware.ts
import { auth } from '@/auth'
import { NextResponse } from 'next/server'

export default auth((req) => {
  const { pathname } = req.nextUrl
  const isLoggedIn = !!req.auth?.user

  const publicPaths = ['/auth/login', '/auth/register', '/auth/error']
  const isPublic = publicPaths.some((p) => pathname.startsWith(p))

  // Allow public paths
  if (isPublic) return NextResponse.next()

  // Redirect to login if not authenticated
  if (!isLoggedIn) {
    return NextResponse.redirect(new URL('/auth/login', req.url))
  }

  // Redirect to onboarding if not setup
  if (!req.auth?.user?.onboardingDone && !pathname.startsWith('/onboarding') && !pathname.startsWith('/api')) {
    return NextResponse.redirect(new URL('/onboarding', req.url))
  }

  return NextResponse.next()
})

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|icon-|manifest.json|api/auth).*)'],
}
