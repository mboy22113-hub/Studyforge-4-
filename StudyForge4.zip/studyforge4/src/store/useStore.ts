// src/store/useStore.ts
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { PlanSession, Quest, StudyTechnique } from '@/types'

interface TimerState {
  technique: StudyTechnique
  phase: 'work' | 'brk'
  secondsLeft: number
  totalSeconds: number
  sessionsCompleted: number
  isRunning: boolean
  focusMinutesToday: number
  selectedSubjectId: string
}

interface UIState {
  sidebarOpen: boolean
  planView: 'daily' | 'weekly' | 'monthly' | 'crisis'
  currentPage: string
}

interface AppStore {
  // Timer
  timer: TimerState
  setTimerState: (patch: Partial<TimerState>) => void
  resetTimer: (technique: StudyTechnique, workMins: number) => void

  // UI
  ui: UIState
  setUI: (patch: Partial<UIState>) => void

  // Local quests cache (synced from server)
  quests: { daily: Quest[]; weekly: Quest[] }
  setQuests: (q: { daily: Quest[]; weekly: Quest[] }) => void
  updateQuestProgress: (type: string, amt: number) => void

  // Today's plan (cached)
  todayPlan: PlanSession[]
  setTodayPlan: (plan: PlanSession[]) => void
  togglePlanTask: (id: string) => void

  // Prayer log today
  todayPrayers: Record<string, boolean>
  togglePrayerLocal: (name: string) => void
  setTodayPrayers: (prayers: Record<string, boolean>) => void
}

export const useStore = create<AppStore>()(
  persist(
    (set) => ({
      timer: {
        technique: 'pomodoro',
        phase: 'work',
        secondsLeft: 25 * 60,
        totalSeconds: 25 * 60,
        sessionsCompleted: 0,
        isRunning: false,
        focusMinutesToday: 0,
        selectedSubjectId: '',
      },
      setTimerState: (patch) =>
        set((s) => ({ timer: { ...s.timer, ...patch } })),
      resetTimer: (technique, workMins) =>
        set((s) => ({
          timer: {
            ...s.timer,
            technique,
            phase: 'work',
            secondsLeft: workMins * 60,
            totalSeconds: workMins * 60,
            sessionsCompleted: 0,
            isRunning: false,
          },
        })),

      ui: {
        sidebarOpen: false,
        planView: 'daily',
        currentPage: 'dashboard',
      },
      setUI: (patch) => set((s) => ({ ui: { ...s.ui, ...patch } })),

      quests: { daily: [], weekly: [] },
      setQuests: (q) => set({ quests: q }),
      updateQuestProgress: (type, amt) =>
        set((s) => {
          const update = (arr: Quest[]) =>
            arr.map((q) => {
              if (q.type !== type || q.done) return q
              const progress = Math.min(q.target, q.progress + amt)
              return { ...q, progress, done: progress >= q.target }
            })
          return {
            quests: {
              daily: update(s.quests.daily),
              weekly: update(s.quests.weekly),
            },
          }
        }),

      todayPlan: [],
      setTodayPlan: (plan) => set({ todayPlan: plan }),
      togglePlanTask: (id) =>
        set((s) => ({
          todayPlan: s.todayPlan.map((t) =>
            t.id === id ? { ...t, done: !t.done } : t,
          ),
        })),

      todayPrayers: {},
      togglePrayerLocal: (name) =>
        set((s) => ({
          todayPrayers: {
            ...s.todayPrayers,
            [name]: !s.todayPrayers[name],
          },
        })),
      setTodayPrayers: (prayers) => set({ todayPrayers: prayers }),
    }),
    {
      name: 'sf40-store',
      partialize: (s) => ({
        timer: { ...s.timer, isRunning: false },
        ui: s.ui,
      }),
    },
  ),
)
