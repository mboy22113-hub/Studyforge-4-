'use client'
// src/components/ui/toaster.tsx
import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/lib/utils'
import { X } from 'lucide-react'

interface Toast { id: string; title: string; description?: string; variant?: 'default' | 'destructive' }

// Global toast state
const listeners: Array<(toasts: Toast[]) => void> = []
let globalToasts: Toast[] = []
let counter = 0

export function toast(props: Omit<Toast, 'id'>) {
  const id = String(++counter)
  globalToasts = [...globalToasts, { ...props, id }]
  listeners.forEach((l) => l([...globalToasts]))
  setTimeout(() => {
    globalToasts = globalToasts.filter((t) => t.id !== id)
    listeners.forEach((l) => l([...globalToasts]))
  }, 4000)
}

export function Toaster() {
  const [toasts, setToasts] = useState<Toast[]>([])

  useEffect(() => {
    listeners.push(setToasts)
    return () => { const idx = listeners.indexOf(setToasts); if (idx > -1) listeners.splice(idx, 1) }
  }, [])

  function dismiss(id: string) {
    globalToasts = globalToasts.filter((t) => t.id !== id)
    listeners.forEach((l) => l([...globalToasts]))
  }

  return (
    <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[9999] flex flex-col gap-2 w-full max-w-sm px-4 pointer-events-none">
      <AnimatePresence mode="sync">
        {toasts.map((t) => (
          <motion.div key={t.id}
            initial={{ opacity: 0, y: 12, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.96 }}
            transition={{ duration: 0.22 }}
            className={cn(
              'pointer-events-auto flex items-start gap-3 rounded-2xl border px-4 py-3 shadow-2xl',
              t.variant === 'destructive'
                ? 'bg-red-950/90 border-red-500/30 backdrop-blur-xl'
                : 'bg-card/95 border-brand-500/25 backdrop-blur-xl',
              'shadow-brand-500/20',
            )}>
            <div className="flex-1 min-w-0">
              <p className="font-syne font-black text-sm leading-tight">{t.title}</p>
              {t.description && <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{t.description}</p>}
            </div>
            <button onClick={() => dismiss(t.id)} className="shrink-0 text-muted-foreground hover:text-foreground transition-colors mt-0.5">
              <X size={14} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}
