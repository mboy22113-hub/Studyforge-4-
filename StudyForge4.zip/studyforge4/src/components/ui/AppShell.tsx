'use client'
// src/components/ui/AppShell.tsx
import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/lib/utils'
import {
  Zap, CalendarDays, Timer, BookOpen,
  BarChart3, Trophy, User, Menu, X, Bell,
} from 'lucide-react'

const NAV = [
  { href: '/dashboard',             icon: Zap,          label: 'Home'     },
  { href: '/dashboard/planner',     icon: CalendarDays, label: 'Planner'  },
  { href: '/dashboard/timer',       icon: Timer,        label: 'Timer'    },
  { href: '/dashboard/subjects',    icon: BookOpen,     label: 'Subjects' },
  { href: '/dashboard/analytics',   icon: BarChart3,    label: 'Stats'    },
  { href: '/dashboard/achievements',icon: Trophy,       label: 'Badges'   },
  { href: '/dashboard/profile',     icon: User,         label: 'Profile'  },
]

interface AppShellProps {
  children: React.ReactNode
  user: { name?: string | null; email?: string | null; image?: string | null }
}

export function AppShell({ children, user }: AppShellProps) {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background flex">

      {/* ── Desktop Sidebar ── */}
      <aside className="hidden lg:flex flex-col w-60 border-r border-border glass sticky top-0 h-screen overflow-y-auto shrink-0">
        <div className="p-5 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center font-syne font-black text-sm text-white glow-brand">
              SF
            </div>
            <div>
              <p className="font-syne font-black text-sm gradient-text-brand">STUDYFORGE</p>
              <p className="text-xs text-muted-foreground">v4.0 AI</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {NAV.map(({ href, icon: Icon, label }) => {
            const active = pathname === href
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all',
                  active
                    ? 'bg-brand-500/15 text-brand-400 font-semibold'
                    : 'text-muted-foreground hover:bg-accent hover:text-foreground',
                )}
              >
                <Icon size={17} className={active ? 'text-brand-400' : ''} />
                {label}
                {active && (
                  <motion.div
                    layoutId="sidebar-active"
                    className="ml-auto w-1.5 h-1.5 rounded-full bg-brand-400"
                  />
                )}
              </Link>
            )
          })}
        </nav>

        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center font-syne font-bold text-xs text-white">
              {(user.name || 'U')[0].toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-medium truncate">{user.name || 'Student'}</p>
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
            </div>
          </div>
        </div>
      </aside>

      {/* ── Mobile Drawer ── */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.aside
              initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 28, stiffness: 280 }}
              className="fixed left-0 top-0 bottom-0 z-50 w-64 bg-card border-r border-border flex flex-col lg:hidden"
            >
              <div className="p-4 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center font-syne font-black text-sm text-white">SF</div>
                  <p className="font-syne font-black text-sm gradient-text-brand">STUDYFORGE</p>
                </div>
                <button onClick={() => setMobileOpen(false)} className="text-muted-foreground hover:text-foreground p-1">
                  <X size={18} />
                </button>
              </div>
              <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
                {NAV.map(({ href, icon: Icon, label }) => {
                  const active = pathname === href
                  return (
                    <Link
                      key={href} href={href}
                      onClick={() => setMobileOpen(false)}
                      className={cn(
                        'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all',
                        active ? 'bg-brand-500/15 text-brand-400 font-semibold' : 'text-muted-foreground hover:bg-accent',
                      )}
                    >
                      <Icon size={17} />{label}
                    </Link>
                  )
                })}
              </nav>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* ── Main area ── */}
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">

        {/* Top bar */}
        <header className="sticky top-0 z-30 h-14 border-b border-border glass flex items-center px-4 gap-3">
          <button
            onClick={() => setMobileOpen(true)}
            className="lg:hidden text-muted-foreground hover:text-foreground p-1"
          >
            <Menu size={20} />
          </button>
          <div className="lg:hidden font-syne font-black text-sm gradient-text-brand">STUDYFORGE</div>
          <div className="ml-auto flex items-center gap-2">
            <button className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-all">
              <Bell size={17} />
            </button>
            <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center font-syne font-bold text-xs text-white">
              {(user.name || 'U')[0].toUpperCase()}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            className="max-w-5xl mx-auto p-4 lg:p-6 pb-24 lg:pb-8"
          >
            {children}
          </motion.div>
        </main>

        {/* Mobile bottom nav */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 border-t border-border glass flex pb-safe">
          {NAV.slice(0, 6).map(({ href, icon: Icon, label }) => {
            const active = pathname === href
            return (
              <Link
                key={href} href={href}
                className={cn(
                  'flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-[10px] font-bold uppercase tracking-wide transition-colors',
                  active ? 'text-brand-400' : 'text-muted-foreground',
                )}
              >
                <Icon size={19} className={active ? 'text-brand-400' : ''} />
                {label}
                {active && <div className="absolute top-0 left-10% right-10% h-0.5 bg-gradient-brand rounded-b" />}
              </Link>
            )
          })}
        </nav>

      </div>
    </div>
  )
}
