'use client'
// src/components/dashboard/DashboardClient.tsx
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { cn, daysUntil, formatDate, getLevelProgress, getLevelFromXP, PRAYER_NAMES, PRAYER_ICONS, PRAYER_DISPLAY } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { Zap, Clock, BookOpen, Flame, CheckCircle2, Circle } from 'lucide-react'

interface Props {
  user: { name?: string | null; college?: string | null; degree?: string | null; semester?: string | null }
  subjects: any[]
  progress: any
  overallRisk: 'safe' | 'mod' | 'high'
  aiInsight: string
  prayerTimes: Record<string, any>
  prayersDone: Record<string, boolean>
}

const RISK_CONFIG = {
  safe: { cls: 'bg-emerald-500/5 border-emerald-500/20', icon: '🟢', title: 'Exam Risk: SAFE',      titleColor: 'text-emerald-400', desc: "You're on track! Keep your daily rhythm." },
  mod:  { cls: 'bg-yellow-500/5  border-yellow-500/20',  icon: '🟡', title: 'Exam Risk: MODERATE',  titleColor: 'text-yellow-400',  desc: 'Some subjects need more attention. Check AI recommendations.' },
  high: { cls: 'bg-red-500/5     border-red-500/25',     icon: '🔴', title: '🚨 CRISIS MODE ACTIVE', titleColor: 'text-red-400',     desc: 'High risk! Emergency revision strategy activated.' },
}

function PrayerHub({ times, done, onToggle }: { times: any; done: Record<string, boolean>; onToggle: (name: string) => void }) {
  const now = new Date()
  const nowMins = now.getHours() * 60 + now.getMinutes()
  const prayerMins = PRAYER_NAMES.map((n) => ({ n, mins: parseInt(times[n]?.split(':')[0] || '0') * 60 + parseInt(times[n]?.split(':')[1] || '0') }))
  const nextIdx = prayerMins.findIndex((p) => p.mins > nowMins)
  const nextPrayer = prayerMins[nextIdx === -1 ? 0 : nextIdx]
  const diff = nextPrayer ? nextPrayer.mins - nowMins : 0
  const timeLabel = diff > 0 ? `${Math.floor(diff / 60) > 0 ? Math.floor(diff / 60) + 'h ' : ''}${diff % 60}m` : ''

  return (
    <div className="rounded-2xl border border-sky-500/15 bg-gradient-to-br from-sky-500/5 to-brand-500/4 p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-sky-300">🕌 Prayer Times</p>
        {timeLabel && <p className="text-xs text-muted-foreground">{PRAYER_DISPLAY[nextPrayer?.n]} in {timeLabel}</p>}
      </div>
      <div className="grid grid-cols-5 gap-1.5">
        {PRAYER_NAMES.map((n, i) => (
          <button
            key={n}
            onClick={() => onToggle(n)}
            className={cn(
              'flex flex-col items-center gap-1 py-2 px-1 rounded-xl border text-center transition-all',
              done[n]             ? 'border-emerald-500/35 bg-emerald-500/8'  : '',
              i === (nextIdx === -1 ? 0 : nextIdx) && !done[n] ? 'border-sky-400/40 bg-sky-400/10' : '',
              !done[n] && i !== (nextIdx === -1 ? 0 : nextIdx) ? 'border-border bg-black/20' : '',
            )}
          >
            <span className="text-xs">{PRAYER_ICONS[n]}</span>
            <span className="text-[9px] font-black uppercase tracking-wide text-sky-300">{PRAYER_DISPLAY[n]}</span>
            <span className="font-mono text-[10px] text-foreground">{times[n]}</span>
            <span className="text-[10px] text-emerald-400 h-3">{done[n] ? '✓' : ''}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

export function DashboardClient({ user, subjects, progress, overallRisk, aiInsight, prayerTimes, prayersDone: initialPrayers }: Props) {
  const { toast } = useToast()
  const [prayers, setPrayers] = useState(initialPrayers)
  const [todayTasks, setTodayTasks] = useState<any[]>([])

  const risk = RISK_CONFIG[overallRisk]
  const xp = progress?.xp || 0
  const level = getLevelFromXP(xp)
  const lvlProg = getLevelProgress(xp)
  const totalDone = subjects.reduce((s: number, sub: any) => s + (sub.chapters?.filter((c: any) => c.completed).length || 0), 0)
  const totalMins = progress?.totalMinutes || 0
  const streak = progress?.streak || 0

  const hr = new Date().getHours()
  const greeting = hr < 4 ? 'Assalamu Alaikum 🌙' : hr < 12 ? 'Assalamu Alaikum ☀️' : hr < 17 ? 'Assalamu Alaikum 🌤' : hr < 20 ? 'Assalamu Alaikum 🌅' : 'Assalamu Alaikum 🌙'

  async function togglePrayer(name: string) {
    const newVal = !prayers[name]
    setPrayers((p) => ({ ...p, [name]: newVal }))

    try {
      await fetch('/api/prayers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date: new Date().toISOString().split('T')[0], prayer: name, done: newVal }),
      })
      if (newVal) toast({ title: '🕌 Prayer Logged', description: `${PRAYER_DISPLAY[name]} ✓ +20 XP` })
      const allDone = PRAYER_NAMES.every((n) => (n === name ? newVal : prayers[n]))
      if (allDone) toast({ title: '🕌 All 5 Prayers!', description: 'MashaAllah! +50 XP 🎉' })
    } catch {
      setPrayers((p) => ({ ...p, [name]: !newVal }))
    }
  }

  const statCards = [
    { label: 'Total XP',   value: xp,                          color: 'text-brand-400',  accent: 'from-brand-500 to-cyan-500', icon: Zap    },
    { label: 'Studied',    value: `${(totalMins/60).toFixed(1)}h`, color: 'text-orange-400', accent: 'from-orange-500 to-yellow-400', icon: Clock  },
    { label: 'Chapters',   value: totalDone,                   color: 'text-emerald-400',accent: 'from-emerald-500 to-cyan-400', icon: BookOpen },
    { label: 'Streak',     value: streak,                      color: 'text-yellow-400', accent: 'from-yellow-500 to-orange-400', icon: Flame  },
  ]

  return (
    <div className="space-y-4">
      {/* Greeting */}
      <motion.div initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} className="rounded-2xl border border-brand-500/15 bg-gradient-to-br from-brand-500/8 to-cyan-500/4 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-syne font-black text-lg">{greeting}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              {user.name} {user.college ? `• ${user.college}` : ''} {user.semester ? `• Sem ${user.semester}` : ''}
            </p>
            {/* Level bar */}
            <div className="flex items-center gap-2 mt-2">
              <span className="text-xs font-syne font-bold text-yellow-400">Lv.{level}</span>
              <div className="w-24 h-1.5 bg-border rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full transition-all" style={{ width: `${lvlProg.pct}%` }} />
              </div>
              <span className="text-xs text-muted-foreground font-mono">{xp} XP</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl gradient-brand flex items-center justify-center font-syne font-black text-xl text-white glow-brand">
            {(user.name || 'S')[0].toUpperCase()}
          </div>
        </div>
      </motion.div>

      {/* Risk Banner */}
      <motion.div initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.05 }}
        className={cn('rounded-2xl border p-3.5 flex items-center gap-3', risk.cls)}>
        <span className="text-2xl">{risk.icon}</span>
        <div>
          <p className={cn('font-syne font-black text-sm', risk.titleColor)}>{risk.title}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{risk.desc}</p>
        </div>
      </motion.div>

      {/* AI Coach */}
      <motion.div initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.08 }}
        className="rounded-2xl border border-brand-500/20 bg-gradient-to-br from-brand-500/6 to-cyan-500/3 p-4">
        <span className="inline-flex items-center gap-1.5 text-[10px] font-black font-syne uppercase tracking-widest text-brand-400 bg-brand-500/15 px-2 py-0.5 rounded-full mb-2">
          🧠 AI Coach
        </span>
        <p className="text-sm text-muted-foreground leading-relaxed" dangerouslySetInnerHTML={{ __html: aiInsight }} />
      </motion.div>

      {/* Prayer Hub */}
      <motion.div initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.1 }}>
        <PrayerHub times={prayerTimes} done={prayers} onToggle={togglePrayer} />
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        {statCards.map(({ label, value, color, accent, icon: Icon }, i) => (
          <motion.div key={label} initial={{ opacity:0, scale:0.95 }} animate={{ opacity:1, scale:1 }} transition={{ delay: 0.12 + i * 0.05 }}
            className="glass rounded-2xl p-3.5 flex items-center gap-3 relative overflow-hidden">
            <div className={cn('absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r', accent)} />
            <Icon size={22} className={cn('shrink-0', color)} />
            <div>
              <p className={cn('font-syne font-black text-xl leading-none', color)}>{value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Exam Countdowns */}
      <div>
        <h2 className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
          Exam Countdowns <div className="flex-1 h-px bg-border" />
        </h2>
        <div className="grid grid-cols-2 gap-2.5">
          {subjects.filter((s: any) => s.examDate).sort((a: any, b: any) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime()).map((sub: any) => {
            const days = daysUntil(sub.examDate)
            const comp = sub.chapters?.filter((c: any) => c.completed).length || 0
            const risk = days <= 7 || (sub.totalChapters - comp) * (sub.difficulty === 'hard' ? 2.5 : 1.6) / Math.max(1,days) > 1.5 ? 'high' : days <= 21 ? 'mod' : 'safe'
            const cls = risk === 'high' ? 'bg-red-500/5 border-red-500/25' : risk === 'mod' ? 'bg-yellow-500/5 border-yellow-500/20' : 'bg-emerald-500/4 border-emerald-500/18'
            const dc = risk === 'high' ? 'text-red-400' : risk === 'mod' ? 'text-yellow-400' : 'text-emerald-400'
            return (
              <div key={sub.id} className={cn('rounded-xl border p-3 relative', cls)}>
                <div className={cn('absolute top-2.5 right-2.5 w-2 h-2 rounded-full', risk==='high'?'bg-red-400 shadow-[0_0_6px_theme(colors.red.400)]':risk==='mod'?'bg-yellow-400 shadow-[0_0_6px_theme(colors.yellow.400)]':'bg-emerald-400 shadow-[0_0_6px_theme(colors.emerald.400)]')} />
                <p className="font-semibold text-sm pr-4" style={{ color: sub.color }}>{sub.name}</p>
                <p className={cn('font-syne font-black text-3xl leading-none mt-1', dc)}>{days >= 0 ? days : '—'}</p>
                <p className="text-xs text-muted-foreground mt-1">{days === 0 ? 'TODAY!' : days === 1 ? 'Tomorrow' : days > 0 ? 'days left' : 'Passed'}</p>
                <p className="text-[10px] text-muted-foreground">{formatDate(sub.examDate)}</p>
              </div>
            )
          })}
        </div>
      </div>

      {/* Subject Progress */}
      <div>
        <h2 className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
          Subject Progress <div className="flex-1 h-px bg-border" />
        </h2>
        <div className="space-y-2.5">
          {subjects.map((sub: any) => {
            const comp = sub.chapters?.filter((c: any) => c.completed).length || 0
            const pct = sub.totalChapters > 0 ? Math.round((comp / sub.totalChapters) * 100) : 0
            return (
              <div key={sub.id}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-semibold" style={{ color: sub.color }}>{sub.name}</span>
                  <span className="font-mono text-xs text-muted-foreground">{pct}%</span>
                </div>
                <div className="h-1.5 bg-border rounded-full overflow-hidden">
                  <motion.div initial={{ width:0 }} animate={{ width:`${pct}%` }} transition={{ duration:.8, ease:'easeOut' }}
                    className="h-full rounded-full" style={{ background: sub.color }} />
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
