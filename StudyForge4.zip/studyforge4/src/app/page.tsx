// src/app/page.tsx
import { redirect } from 'next/navigation'
import { auth } from '@/auth'

export default async function RootPage() {
  const session = await auth()

  if (!session?.user) {
    redirect('/auth/login')
  }

  if (!session.user.onboardingDone) {
    redirect('/onboarding')
  }

  redirect('/dashboard')
}
