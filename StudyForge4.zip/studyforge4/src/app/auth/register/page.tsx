'use client'
// src/app/auth/register/page.tsx
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { signIn } from 'next-auth/react'
import { motion } from 'framer-motion'
import Link from 'next/link'

export default function RegisterPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({ name:'', age:'', email:'', password:'', college:'', degree:'', semester:'4th', department:'' })
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setForm(f => ({ ...f, [k]: e.target.value }))

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, age: parseInt(form.age) || 20 }),
      })
      if (!res.ok) { const d = await res.json(); setError(d.error || 'Registration failed'); setLoading(false); return }
      // Auto sign-in
      await signIn('credentials', { email: form.email, password: form.password, redirect: false })
      router.push('/onboarding')
    } catch { setError('Something went wrong'); setLoading(false) }
  }

  const fields = [
    { key:'name',       label:'Full Name',   type:'text',   placeholder:'Ahmed Khan',           col:1 },
    { key:'age',        label:'Age',         type:'number', placeholder:'20',                   col:1 },
    { key:'email',      label:'Email',       type:'email',  placeholder:'your@email.com',       col:2 },
    { key:'password',   label:'Password',    type:'password',placeholder:'Min 6 characters',   col:2 },
    { key:'college',    label:'College',     type:'text',   placeholder:'e.g. FAST NUCES',      col:2 },
    { key:'degree',     label:'Degree',      type:'text',   placeholder:'e.g. BS Computer Sci', col:2 },
    { key:'department', label:'Department',  type:'text',   placeholder:'e.g. CS&IT',           col:2 },
  ]

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 overflow-y-auto">
      <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} className="w-full max-w-md py-6">
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl gradient-brand mx-auto flex items-center justify-center font-syne font-black text-lg text-white glow-brand mb-3">SF</div>
          <h1 className="font-syne font-black text-2xl gradient-text-brand">Create Account</h1>
          <p className="text-muted-foreground text-sm mt-1">Join 10,000+ students on StudyForge</p>
        </div>

        <div className="glass rounded-2xl p-5 border border-border">
          <div className="flex gap-1.5 bg-muted rounded-xl p-1 mb-5">
            <Link href="/auth/login" className="flex-1 py-2 rounded-lg text-muted-foreground text-sm font-semibold text-center hover:text-foreground transition-colors">Sign In</Link>
            <div className="flex-1 py-2 rounded-lg bg-brand-500 text-white text-sm font-semibold text-center">Register</div>
          </div>

          <form onSubmit={handleRegister} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              {fields.map(({ key, label, type, placeholder, col }) => (
                <div key={key} className={col === 2 ? 'col-span-2' : ''}>
                  <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">{label}</label>
                  <input type={type} value={(form as any)[key]} onChange={set(key)} placeholder={placeholder}
                    className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all" />
                </div>
              ))}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Semester</label>
                <select value={form.semester} onChange={set('semester')} className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm outline-none focus:border-brand-500 transition-all">
                  {['1st','2nd','3rd','4th','5th','6th','7th','8th'].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>

            {error && <p className="text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">{error}</p>}

            <button type="submit" disabled={loading}
              className="w-full py-2.5 rounded-xl gradient-brand text-white font-syne font-bold text-sm glow-brand hover:opacity-90 transition-all disabled:opacity-60 mt-2">
              {loading ? 'Creating account…' : 'Create Account →'}
            </button>
          </form>

          <div className="flex items-center gap-3 my-4 text-xs text-muted-foreground">
            <div className="flex-1 h-px bg-border"/><span>or</span><div className="flex-1 h-px bg-border"/>
          </div>
          <button onClick={() => signIn('google', { callbackUrl:'/onboarding' })}
            className="w-full py-2.5 rounded-xl bg-muted border border-border text-sm font-medium flex items-center justify-center gap-2.5 hover:bg-accent transition-all">
            <svg width="17" height="17" viewBox="0 0 18 18"><path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"/><path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332C2.438 15.983 5.482 18 9 18z"/><path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/><path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0 5.482 0 2.438 2.017.957 4.958L3.964 6.29C4.672 4.163 6.656 3.58 9 3.58z"/></svg>
            Continue with Google
          </button>
        </div>
      </motion.div>
    </div>
  )
}
