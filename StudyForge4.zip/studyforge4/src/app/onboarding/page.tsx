'use client'
// src/app/onboarding/page.tsx
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { cn, SUBJECT_COLORS } from '@/lib/utils'
import { Plus, Trash2, ChevronRight, ChevronLeft, Rocket } from 'lucide-react'

const TOTAL_STEPS = 5

interface SubjectForm {
  name: string; difficulty: 'easy'|'medium'|'hard'; totalChapters: number
  examDate: string; previousMark: number; targetMark: number
  confidence: 'low'|'med'|'high'; topics: string
}
function newSub(): SubjectForm {
  return { name:'', difficulty:'medium', totalChapters:8, examDate:'', previousMark:60, targetMark:80, confidence:'low', topics:'' }
}

export default function OnboardingPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Step 1
  const [sem, setSem] = useState({ name:'', start:'', end:'', holidays:10, dailyHours:4 })
  const [routine, setRoutine] = useState({ wake:'04:45', sleep:'23:00', col:'08:00', cole:'14:00', trav:1 })
  // Step 2
  const [subjects, setSubjects] = useState<SubjectForm[]>([newSub()])
  // Step 3
  const [prayers, setPrayers] = useState({ fajr:'05:00', dhuhr:'12:30', asr:'15:45', maghrib:'18:15', isha:'20:00', duration:20 })
  // Step 4
  const [prefs, setPrefs] = useState({ reward:'gaming', tech:'pomodoro' })

  const addSub = () => setSubjects(s => [...s, newSub()])
  const removeSub = (i: number) => setSubjects(s => s.filter((_, idx) => idx !== i))
  const updateSub = (i: number, patch: Partial<SubjectForm>) =>
    setSubjects(s => s.map((sub, idx) => idx === i ? { ...sub, ...patch } : sub))

  async function finish() {
    setLoading(true); setError('')
    try {
      const res = await fetch('/api/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          semesterName: sem.name || 'My Semester',
          semesterStart: sem.start || new Date().toISOString().split('T')[0],
          semesterEnd: sem.end || new Date(Date.now() + 150*86400000).toISOString().split('T')[0],
          holidays: sem.holidays, dailyHours: sem.dailyHours,
          wakeUpTime: routine.wake, sleepTime: routine.sleep,
          collegeStart: routine.col, collegeEnd: routine.cole, travelHours: routine.trav,
          preferredTech: prefs.tech, preferredReward: prefs.reward,
          prayers,
          subjects: subjects.filter(s => s.name.trim()).map(s => ({
            name: s.name, difficulty: s.difficulty, totalChapters: s.totalChapters,
            examDate: s.examDate || null, previousMark: s.previousMark, targetMark: s.targetMark,
            confidence: s.confidence,
            topics: s.topics.split('\n').map(t => t.trim()).filter(Boolean),
          })),
        }),
      })
      if (!res.ok) { const d = await res.json(); setError(d.error || 'Setup failed'); setLoading(false); return }
      router.push('/dashboard')
    } catch { setError('Something went wrong'); setLoading(false) }
  }

  const REWARDS = [
    { id:'gaming', label:'Gaming', e:'🎮' }, { id:'music', label:'Music', e:'🎵' },
    { id:'workout', label:'Workout', e:'💪' }, { id:'social', label:'Social', e:'📱' },
    { id:'videos', label:'Videos', e:'🎬' }, { id:'sleep', label:'Nap', e:'😴' },
  ]
  const TECHS = [
    { id:'pomodoro', label:'🍅 Pomodoro (25/5)', desc:'Best for memorization' },
    { id:'5010', label:'⚡ 50/10 Focus', desc:'Deep problem solving' },
    { id:'deepwork', label:'🧠 Deep Work (90m)', desc:'Maximum focus depth' },
  ]
  const PRAYERS_LIST = [
    { key:'fajr', icon:'🌙', label:'Fajr' }, { key:'dhuhr', icon:'☀️', label:'Dhuhr' },
    { key:'asr', icon:'🌤', label:'Asr' }, { key:'maghrib', icon:'🌅', label:'Maghrib' },
    { key:'isha', icon:'🌃', label:'Isha' },
  ]

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-start p-4 overflow-y-auto">
      <div className="w-full max-w-lg py-6">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl gradient-brand mx-auto flex items-center justify-center font-syne font-black text-lg text-white glow-brand mb-3 relative">
            SF
            <span className="absolute -top-1 -right-2 bg-emerald-500 text-black text-[9px] font-black px-1 rounded-md">AI</span>
          </div>
          <h1 className="font-syne font-black text-2xl gradient-text-brand">Setup Your Study OS</h1>
          <p className="text-muted-foreground text-sm mt-1">Step {step} of {TOTAL_STEPS}</p>
        </div>

        {/* Progress bar */}
        <div className="flex gap-1.5 mb-6">
          {Array.from({ length: TOTAL_STEPS }, (_, i) => (
            <div key={i} className={cn('flex-1 h-1.5 rounded-full transition-all duration-500',
              i + 1 < step ? 'bg-emerald-500' : i + 1 === step ? 'bg-brand-500 shadow-[0_0_8px_theme(colors.brand.500)]' : 'bg-border')} />
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div key={step} initial={{ opacity:0, x:30 }} animate={{ opacity:1, x:0 }} exit={{ opacity:0, x:-30 }} transition={{ duration:.25 }}
            className="glass rounded-2xl border border-border p-5">

            {/* ── Step 1: Semester ── */}
            {step === 1 && (
              <div>
                <h2 className="font-syne font-black text-lg mb-1">📚 Semester Details</h2>
                <p className="text-sm text-muted-foreground mb-4">The AI uses this to build your optimized study roadmap.</p>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label:'Session Name', key:'name', type:'text', placeholder:'e.g. Final Exams 2025', col:2 },
                    { label:'Daily Study Hours', key:'dailyHours', type:'number', placeholder:'4', col:1 },
                    { label:'Study Holidays', key:'holidays', type:'number', placeholder:'10', col:1 },
                    { label:'Semester Start', key:'start', type:'date', placeholder:'', col:1 },
                    { label:'Semester End', key:'end', type:'date', placeholder:'', col:1 },
                  ].map(({ label, key, type, placeholder, col }) => (
                    <div key={key} className={col === 2 ? 'col-span-2' : ''}>
                      <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">{label}</label>
                      <input type={type} value={(sem as any)[key]} onChange={e => setSem(s => ({ ...s, [key]: type === 'number' ? parseFloat(e.target.value) : e.target.value }))}
                        placeholder={placeholder}
                        className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all" />
                    </div>
                  ))}
                </div>
                <p className="font-syne font-bold text-xs uppercase tracking-widest text-muted-foreground mt-4 mb-3">Daily Routine</p>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label:'Wake Up', key:'wake', type:'time' }, { label:'Sleep', key:'sleep', type:'time' },
                    { label:'College Start', key:'col', type:'time' }, { label:'College End', key:'cole', type:'time' },
                    { label:'Travel (hrs/day)', key:'trav', type:'number' },
                  ].map(({ label, key, type }) => (
                    <div key={key}>
                      <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">{label}</label>
                      <input type={type} value={(routine as any)[key]} onChange={e => setRoutine(r => ({ ...r, [key]: type === 'number' ? parseFloat(e.target.value) : e.target.value }))} step={type === 'number' ? 0.5 : undefined}
                        className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ── Step 2: Subjects ── */}
            {step === 2 && (
              <div>
                <h2 className="font-syne font-black text-lg mb-1">🎯 Your Subjects</h2>
                <p className="text-sm text-muted-foreground mb-4">AI scores each subject by difficulty, confidence & marks to build your priority engine.</p>
                <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
                  {subjects.map((sub, i) => (
                    <div key={i} className="bg-muted/50 border border-border rounded-xl p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-syne font-black text-sm" style={{ color: SUBJECT_COLORS[i % SUBJECT_COLORS.length] }}>Subject {i + 1}</span>
                        {subjects.length > 1 && (
                          <button onClick={() => removeSub(i)} className="text-muted-foreground hover:text-red-400 transition-colors"><Trash2 size={14} /></button>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-2.5">
                        <div className="col-span-2">
                          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Subject Name</label>
                          <input value={sub.name} onChange={e => updateSub(i, { name: e.target.value })} placeholder="e.g. Mathematics"
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm outline-none focus:border-brand-500 transition-all" />
                        </div>
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Exam Date</label>
                          <input type="date" value={sub.examDate} onChange={e => updateSub(i, { examDate: e.target.value })}
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm outline-none focus:border-brand-500 transition-all" />
                        </div>
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Difficulty</label>
                          <select value={sub.difficulty} onChange={e => updateSub(i, { difficulty: e.target.value as any })}
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm outline-none focus:border-brand-500 transition-all">
                            <option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Chapters</label>
                          <input type="number" value={sub.totalChapters} onChange={e => updateSub(i, { totalChapters: parseInt(e.target.value) || 8 })} min={1} max={80}
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm outline-none focus:border-brand-500 transition-all" />
                        </div>
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Prev Mark %</label>
                          <input type="number" value={sub.previousMark} onChange={e => updateSub(i, { previousMark: parseInt(e.target.value) || 0 })} min={0} max={100}
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm outline-none focus:border-brand-500 transition-all" />
                        </div>
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Target %</label>
                          <input type="number" value={sub.targetMark} onChange={e => updateSub(i, { targetMark: parseInt(e.target.value) || 80 })} min={0} max={100}
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm outline-none focus:border-brand-500 transition-all" />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Confidence</label>
                          <div className="grid grid-cols-3 gap-1.5">
                            {(['low','med','high'] as const).map(c => (
                              <button key={c} type="button" onClick={() => updateSub(i, { confidence: c })}
                                className={cn('py-1.5 rounded-lg border text-xs font-bold transition-all',
                                  sub.confidence === c
                                    ? c === 'low' ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400' : c === 'med' ? 'border-yellow-500 bg-yellow-500/10 text-yellow-400' : 'border-red-500 bg-red-500/10 text-red-400'
                                    : 'border-border text-muted-foreground hover:border-border/60')}>
                                {c === 'low' ? '😰 Low' : c === 'med' ? '😐 Medium' : '😎 High'}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="col-span-2">
                          <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Key Topics (one per line)</label>
                          <textarea value={sub.topics} onChange={e => updateSub(i, { topics: e.target.value })} rows={2}
                            placeholder="e.g. Integration, Limits, Derivatives…"
                            className="w-full px-3 py-2 bg-background border border-border rounded-lg text-sm outline-none focus:border-brand-500 transition-all resize-none" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={addSub}
                  className="w-full mt-3 py-2.5 rounded-xl border-2 border-dashed border-border text-muted-foreground text-sm font-medium flex items-center justify-center gap-2 hover:border-brand-500 hover:text-brand-400 transition-all">
                  <Plus size={16} /> Add Subject
                </button>
              </div>
            )}

            {/* ── Step 3: Prayer Times ── */}
            {step === 3 && (
              <div>
                <h2 className="font-syne font-black text-lg mb-1">🕌 Prayer Schedule</h2>
                <p className="text-sm text-muted-foreground mb-4">All 5 prayers are auto-blocked in your schedule. The focus timer alerts you 2 minutes before each prayer.</p>
                <div className="grid grid-cols-2 gap-2.5">
                  {PRAYERS_LIST.map(({ key, icon, label }) => (
                    <div key={key} className="bg-muted/50 border border-sky-500/15 rounded-xl p-3 flex items-center gap-3">
                      <span className="text-xl">{icon}</span>
                      <div className="flex-1">
                        <label className="block text-[10px] font-black uppercase tracking-wider text-sky-400 mb-1">{label}</label>
                        <input type="time" value={(prayers as any)[key]} onChange={e => setPrayers(p => ({ ...p, [key]: e.target.value }))}
                          className="w-full bg-transparent border-none text-sm font-mono outline-none text-foreground" />
                      </div>
                    </div>
                  ))}
                  <div className="bg-muted/50 border border-border rounded-xl p-3 flex items-center gap-3">
                    <span className="text-xl">⏱</span>
                    <div className="flex-1">
                      <label className="block text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-1">Duration (min)</label>
                      <input type="number" value={prayers.duration} onChange={e => setPrayers(p => ({ ...p, duration: parseInt(e.target.value) || 20 }))} min={5} max={60}
                        className="w-full bg-transparent border-none text-sm font-mono outline-none text-foreground" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ── Step 4: Preferences ── */}
            {step === 4 && (
              <div>
                <h2 className="font-syne font-black text-lg mb-1">🎮 Preferences</h2>
                <p className="text-sm text-muted-foreground mb-4">Customize how StudyForge rewards and motivates you.</p>
                <p className="font-syne font-bold text-xs uppercase tracking-widest text-muted-foreground mb-2">Favourite Reward</p>
                <div className="grid grid-cols-3 gap-2 mb-5">
                  {REWARDS.map(r => (
                    <button key={r.id} onClick={() => setPrefs(p => ({ ...p, reward: r.id }))}
                      className={cn('flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 text-xl transition-all',
                        prefs.reward === r.id ? 'border-brand-500 bg-brand-500/10' : 'border-border hover:border-border/60')}>
                      {r.e}<span className="text-[11px] font-semibold text-muted-foreground">{r.label}</span>
                    </button>
                  ))}
                </div>
                <p className="font-syne font-bold text-xs uppercase tracking-widest text-muted-foreground mb-2">Study Technique</p>
                <div className="space-y-2">
                  {TECHS.map(t => (
                    <button key={t.id} onClick={() => setPrefs(p => ({ ...p, tech: t.id }))}
                      className={cn('w-full flex items-center gap-3 p-3 rounded-xl border-2 text-left transition-all',
                        prefs.tech === t.id ? 'border-brand-500 bg-brand-500/10' : 'border-border hover:border-brand-500/30')}>
                      <div className="flex-1">
                        <p className="text-sm font-semibold">{t.label}</p>
                        <p className="text-xs text-muted-foreground">{t.desc}</p>
                      </div>
                      {prefs.tech === t.id && <div className="w-2.5 h-2.5 rounded-full bg-brand-500" />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ── Step 5: Confirm ── */}
            {step === 5 && (
              <div className="text-center">
                <div className="text-5xl mb-4">🚀</div>
                <h2 className="font-syne font-black text-xl mb-2">You're all set!</h2>
                <p className="text-muted-foreground text-sm mb-6">The AI will now generate your personalized study plan, daily timetable, and revision schedule based on everything you've told us.</p>
                <div className="grid grid-cols-2 gap-3 text-left mb-6">
                  {[
                    { label:'Subjects', value:`${subjects.filter(s=>s.name).length} added` },
                    { label:'Daily Hours', value:`${sem.dailyHours}h planned` },
                    { label:'Prayer Times', value:'5 prayers configured' },
                    { label:'Study Tech', value:prefs.tech },
                  ].map(({ label, value }) => (
                    <div key={label} className="bg-muted/50 rounded-xl p-3 border border-border">
                      <p className="text-xs text-muted-foreground font-medium">{label}</p>
                      <p className="text-sm font-semibold mt-0.5">{value}</p>
                    </div>
                  ))}
                </div>
                {error && <p className="text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2 mb-3">{error}</p>}
                <button onClick={finish} disabled={loading}
                  className="w-full py-3 rounded-xl gradient-brand text-white font-syne font-black text-base glow-brand hover:opacity-90 transition-all disabled:opacity-60 flex items-center justify-center gap-2">
                  {loading ? 'Generating AI Plan…' : <><Rocket size={18} /> Generate My Study Plan</>}
                </button>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        {step < 5 && (
          <div className="flex justify-between mt-4">
            <button onClick={() => setStep(s => Math.max(1, s - 1))} disabled={step === 1}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-muted border border-border text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-all disabled:opacity-40">
              <ChevronLeft size={16} /> Back
            </button>
            <button onClick={() => setStep(s => Math.min(TOTAL_STEPS, s + 1))}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl gradient-brand text-white font-syne font-bold text-sm glow-brand hover:opacity-90 transition-all">
              Continue <ChevronRight size={16} />
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
