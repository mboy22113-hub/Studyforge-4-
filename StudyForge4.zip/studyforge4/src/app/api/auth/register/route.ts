// src/app/api/auth/register/route.ts
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'

const schema = z.object({
  name:       z.string().min(2),
  email:      z.string().email(),
  password:   z.string().min(6),
  age:        z.number().optional(),
  college:    z.string().optional(),
  degree:     z.string().optional(),
  semester:   z.string().optional(),
  department: z.string().optional(),
})

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const data = schema.parse(body)

    const existing = await prisma.user.findUnique({ where: { email: data.email } })
    if (existing) {
      return NextResponse.json({ error: 'Email already registered' }, { status: 400 })
    }

    // In production: hash password with bcrypt
    const user = await prisma.user.create({
      data: {
        name:       data.name,
        email:      data.email,
        password:   data.password,   // store hashed in production
        age:        data.age,
        college:    data.college,
        degree:     data.degree,
        semester:   data.semester,
        department: data.department,
        progress: { create: {} },
      },
    })

    return NextResponse.json({ id: user.id, email: user.email })
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: err.errors }, { status: 422 })
    }
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}
