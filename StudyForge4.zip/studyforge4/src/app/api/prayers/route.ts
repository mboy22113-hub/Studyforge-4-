// src/app/api/prayers/route.ts
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const schema = z.object({
  date:    z.string(),
  prayer:  z.enum(['fajr', 'dhuhr', 'asr', 'maghrib', 'isha']),
  done:    z.boolean(),
})

export async function GET(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const date = searchParams.get('date') || new Date().toISOString().split('T')[0]

  const log = await prisma.prayerLog.findFirst({
    where: { userId: session.user.id, date: new Date(date) },
  })

  return NextResponse.json(log || {})
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { date, prayer, done } = schema.parse(body)

  const log = await prisma.prayerLog.upsert({
    where:  { userId_date: { userId: session.user.id, date: new Date(date) } },
    create: { userId: session.user.id, date: new Date(date), [prayer]: done },
    update: { [prayer]: done },
  })

  // Award XP for prayer
  if (done) {
    await prisma.userProgress.upsert({
      where:  { userId: session.user.id },
      create: { userId: session.user.id, xp: 20, coins: 4 },
      update: { xp: { increment: 20 }, coins: { increment: 4 } },
    })
  }

  return NextResponse.json(log)
}

// GET all prayer logs for stats
export async function PUT(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const logs = await prisma.prayerLog.findMany({
    where:   { userId: session.user.id },
    orderBy: { date: 'desc' },
    take:    90,
  })

  return NextResponse.json(logs)
}
