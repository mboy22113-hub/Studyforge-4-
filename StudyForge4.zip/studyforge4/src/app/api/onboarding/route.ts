// src/app/api/onboarding/route.ts
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import { SUBJECT_COLORS } from '@/lib/utils'

const schema = z.object({
  semesterName:   z.string(),
  semesterStart:  z.string(),
  semesterEnd:    z.string(),
  holidays:       z.number().default(10),
  dailyHours:     z.number().default(4),
  wakeUpTime:     z.string().default('05:00'),
  sleepTime:      z.string().default('23:00'),
  collegeStart:   z.string().default('08:00'),
  collegeEnd:     z.string().default('14:00'),
  travelHours:    z.number().default(1),
  preferredTech:  z.string().default('pomodoro'),
  preferredReward:z.string().default('gaming'),
  prayers: z.object({
    fajr: z.string(), dhuhr: z.string(), asr: z.string(),
    maghrib: z.string(), isha: z.string(), duration: z.number(),
  }),
  subjects: z.array(z.object({
    name:         z.string(),
    difficulty:   z.enum(['easy','medium','hard']),
    totalChapters:z.number(),
    examDate:     z.string().optional(),
    previousMark: z.number().optional(),
    targetMark:   z.number().optional(),
    confidence:   z.enum(['low','med','high']),
    topics:       z.array(z.string()).optional(),
  })),
})

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const data = schema.parse(body)
  const userId = session.user.id

  await prisma.$transaction(async (tx) => {
    // Update user preferences
    await tx.user.update({
      where: { id: userId },
      data: {
        dailyStudyHours: data.dailyHours,
        preferredTech:   data.preferredTech,
        preferredReward: data.preferredReward,
        wakeUpTime:      data.wakeUpTime,
        sleepTime:       data.sleepTime,
        onboardingDone:  true,
      },
    })

    // Create semester
    const semester = await tx.semester.create({
      data: {
        userId,
        name:      data.semesterName,
        startDate: new Date(data.semesterStart),
        endDate:   new Date(data.semesterEnd),
        holidays:  data.holidays,
      },
    })

    // Create subjects with chapters and topics
    for (let i = 0; i < data.subjects.length; i++) {
      const s = data.subjects[i]
      await tx.subject.create({
        data: {
          userId,
          semesterId:    semester.id,
          name:          s.name,
          color:         SUBJECT_COLORS[i % SUBJECT_COLORS.length],
          difficulty:    s.difficulty,
          totalChapters: s.totalChapters,
          examDate:      s.examDate ? new Date(s.examDate) : null,
          previousMark:  s.previousMark,
          targetMark:    s.targetMark || 80,
          confidence:    s.confidence,
          chapters: {
            create: Array.from({ length: s.totalChapters }, (_, ci) => ({
              number: ci + 1,
              title:  `Chapter ${ci + 1}`,
            })),
          },
          topics: s.topics?.length ? {
            create: s.topics.map((text, ti) => ({ text, order: ti })),
          } : undefined,
        },
      })
    }

    // Create initial prayer log for today
    const today = new Date(); today.setHours(0,0,0,0)
    await tx.prayerLog.upsert({
      where:  { userId_date: { userId, date: today } },
      create: {
        userId, date: today,
        fajrTime:    data.prayers.fajr,
        dhuhrTime:   data.prayers.dhuhr,
        asrTime:     data.prayers.asr,
        maghribTime: data.prayers.maghrib,
        ishaTime:    data.prayers.isha,
        duration:    data.prayers.duration,
      },
      update: {
        fajrTime:    data.prayers.fajr,
        dhuhrTime:   data.prayers.dhuhr,
        asrTime:     data.prayers.asr,
        maghribTime: data.prayers.maghrib,
        ishaTime:    data.prayers.isha,
        duration:    data.prayers.duration,
      },
    })

    // Initialize progress
    await tx.userProgress.upsert({
      where:  { userId },
      create: { userId },
      update: {},
    })
  })

  return NextResponse.json({ success: true })
}
