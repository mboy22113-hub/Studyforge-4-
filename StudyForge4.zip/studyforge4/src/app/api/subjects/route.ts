// src/app/api/subjects/route.ts
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const subjectSchema = z.object({
  name:          z.string().min(1),
  color:         z.string().default('#7b5ea7'),
  difficulty:    z.enum(['easy','medium','hard']).default('medium'),
  totalChapters: z.number().min(1).max(80).default(8),
  examDate:      z.string().nullable().optional(),
  previousMark:  z.number().min(0).max(100).optional(),
  targetMark:    z.number().min(0).max(100).default(80),
  confidence:    z.enum(['low','med','high']).default('low'),
  topics:        z.array(z.string()).optional(),
  semesterId:    z.string().optional(),
})

export async function GET() {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const subjects = await prisma.subject.findMany({
    where: { userId: session.user.id },
    include: { chapters: { orderBy: { number: 'asc' } }, topics: { orderBy: { order: 'asc' } } },
    orderBy: { createdAt: 'asc' },
  })

  return NextResponse.json(subjects)
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const body = await req.json()
    const data = subjectSchema.parse(body)

    const subject = await prisma.subject.create({
      data: {
        userId:        session.user.id,
        name:          data.name,
        color:         data.color,
        difficulty:    data.difficulty,
        totalChapters: data.totalChapters,
        examDate:      data.examDate ? new Date(data.examDate) : null,
        previousMark:  data.previousMark,
        targetMark:    data.targetMark,
        confidence:    data.confidence,
        semesterId:    data.semesterId,
        // Create chapters
        chapters: {
          create: Array.from({ length: data.totalChapters }, (_, i) => ({
            number: i + 1,
            title:  `Chapter ${i + 1}`,
          })),
        },
        // Create topics
        topics: data.topics?.length ? {
          create: data.topics.map((text, i) => ({ text, order: i })),
        } : undefined,
      },
      include: { chapters: true, topics: true },
    })

    return NextResponse.json(subject, { status: 201 })
  } catch (err) {
    if (err instanceof z.ZodError) return NextResponse.json({ error: err.errors }, { status: 422 })
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}
