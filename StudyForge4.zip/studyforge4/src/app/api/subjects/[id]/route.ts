// src/app/api/subjects/[id]/route.ts
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/prisma'

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const subject = await prisma.subject.findFirst({
    where: { id: params.id, userId: session.user.id },
    include: { chapters: { orderBy: { number: 'asc' } }, topics: true, files: true },
  })

  if (!subject) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(subject)
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()

  const subject = await prisma.subject.updateMany({
    where: { id: params.id, userId: session.user.id },
    data: body,
  })

  return NextResponse.json({ updated: subject.count })
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  await prisma.subject.deleteMany({
    where: { id: params.id, userId: session.user.id },
  })

  return NextResponse.json({ deleted: true })
}
