// src/app/api/subjects/[id]/chapters/[chapterId]/route.ts
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/prisma'

export async function PATCH(
  req: Request,
  { params }: { params: { id: string; chapterId: string } },
) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()

  // Verify subject ownership
  const subject = await prisma.subject.findFirst({
    where: { id: params.id, userId: session.user.id },
  })
  if (!subject) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const chapter = await prisma.chapter.update({
    where: { id: params.chapterId },
    data: {
      completed:   body.completed,
      completedAt: body.completed ? new Date() : null,
    },
  })

  // Award XP if completed
  if (body.completed) {
    await prisma.userProgress.upsert({
      where:  { userId: session.user.id },
      create: { userId: session.user.id, xp: 30, coins: 6 },
      update: { xp: { increment: 30 }, coins: { increment: 6 } },
    })
  }

  return NextResponse.json(chapter)
}
