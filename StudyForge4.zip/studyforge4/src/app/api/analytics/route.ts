// src/app/api/analytics/route.ts
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/prisma'
import { getRiskLevel } from '@/lib/utils'

export async function GET() {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const userId = session.user.id

  // Last 7 days study hours
  const sevenDaysAgo = new Date()
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

  const [sessions, progress, subjects, prayerLogs, achievements] = await Promise.all([
    prisma.studySession.findMany({
      where:   { userId, date: { gte: sevenDaysAgo } },
      orderBy: { date: 'asc' },
    }),
    prisma.userProgress.findUnique({ where: { userId } }),
    prisma.subject.findMany({
      where:   { userId },
      include: { chapters: true },
    }),
    prisma.prayerLog.findMany({
      where:   { userId },
      orderBy: { date: 'desc' },
      take:    30,
    }),
    prisma.userAchievement.findMany({ where: { userId } }),
  ])

  // Hours per day (last 7)
  const hoursPerDay: Record<string, number> = {}
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i)
    const key = d.toISOString().split('T')[0]
    hoursPerDay[key] = 0
  }
  sessions.forEach((s) => {
    const key = new Date(s.date).toISOString().split('T')[0]
    if (key in hoursPerDay) hoursPerDay[key] += s.durationMin / 60
  })

  // Subject distribution
  const subjectMins: Record<string, number> = {}
  sessions.forEach((s) => {
    if (s.subjectId) subjectMins[s.subjectId] = (subjectMins[s.subjectId] || 0) + s.durationMin
  })

  // Prayer consistency
  const prayerStats = { fajr:0, dhuhr:0, asr:0, maghrib:0, isha:0 }
  prayerLogs.forEach((l) => {
    if (l.fajr)   prayerStats.fajr++
    if (l.dhuhr)  prayerStats.dhuhr++
    if (l.asr)    prayerStats.asr++
    if (l.maghrib)prayerStats.maghrib++
    if (l.isha)   prayerStats.isha++
  })

  // Exam readiness per subject
  const examReadiness = subjects.map((s) => {
    const completed = s.chapters.filter((c) => c.completed).length
    const pct = s.totalChapters > 0 ? Math.round((completed / s.totalChapters) * 100) : 0
    const risk = getRiskLevel(s.totalChapters, completed, s.difficulty, s.examDate)
    return { id: s.id, name: s.name, color: s.color, pct, risk }
  })

  // Productivity score
  const todayKey = new Date().toISOString().split('T')[0]
  const todayLog = prayerLogs.find((l) => l.date.toISOString().split('T')[0] === todayKey)
  const prayersDoneToday = todayLog
    ? [todayLog.fajr, todayLog.dhuhr, todayLog.asr, todayLog.maghrib, todayLog.isha].filter(Boolean).length
    : 0
  const todayMins = sessions
    .filter((s) => new Date(s.date).toISOString().split('T')[0] === todayKey)
    .reduce((sum, s) => sum + s.durationMin, 0)
  const streakScore = Math.min(1, (progress?.streak || 0) / 30)
  const hoursScore  = Math.min(1, (todayMins / 60) / 4)
  const prayerScore = prayersDoneToday / 5
  const productivityScore = Math.round((streakScore * 25 + hoursScore * 40 + prayerScore * 20 + 0.15) * 100)

  return NextResponse.json({
    hoursPerDay,
    subjectMins,
    prayerStats,
    examReadiness,
    productivityScore: Math.min(100, productivityScore),
    progress,
    achievements: achievements.map((a) => a.achievementId),
  })
}
