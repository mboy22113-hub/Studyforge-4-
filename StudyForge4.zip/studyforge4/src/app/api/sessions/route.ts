// src/app/api/sessions/route.ts
import { NextResponse } from 'next/server'
import { auth } from '@/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const schema = z.object({
  subjectId:   z.string().optional(),
  technique:   z.enum(['pomodoro', '5010', 'deepwork']),
  durationMin: z.number().min(1).max(180),
  type:        z.enum(['study', 'revision', 'practice']).default('study'),
})

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const data = schema.parse(body)

  const xpEarned = data.durationMin

  const [studySession] = await prisma.$transaction([
    prisma.studySession.create({
      data: { userId: session.user.id, ...data, xpEarned },
    }),
    prisma.userProgress.upsert({
      where:  { userId: session.user.id },
      create: { userId: session.user.id, xp: xpEarned, totalMinutes: data.durationMin, coins: Math.floor(xpEarned / 5) },
      update: {
        xp:           { increment: xpEarned },
        totalMinutes: { increment: data.durationMin },
        coins:        { increment: Math.floor(xpEarned / 5) },
      },
    }),
  ])

  return NextResponse.json(studySession, { status: 201 })
}

export async function GET(req: Request) {
  const session = await auth()
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const days = parseInt(searchParams.get('days') || '7')

  const from = new Date()
  from.setDate(from.getDate() - days)

  const sessions = await prisma.studySession.findMany({
    where:   { userId: session.user.id, date: { gte: from } },
    orderBy: { date: 'desc' },
  })

  return NextResponse.json(sessions)
}
