'use client'
// src/app/dashboard/profile/page.tsx
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { signOut, useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { cn, getLevelFromXP } from '@/lib/utils'
import { LogOut, Download, Upload, Smartphone, Bell, Moon, Trash2, ChevronRight } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export default function ProfilePage() {
  const { data: session } = useSession()
  const router = useRouter()
  const { toast } = useToast()
  const [progress, setProgress] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/analytics').then(r => r.json()).then(d => {
      setProgress(d.progress)
      setLoading(false)
    })
  }, [])

  const user = session?.user
  const xp = progress?.xp || 0
  const level = getLevelFromXP(xp)
  const initials = (user?.name || 'S').split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2)

  async function exportData() {
    try {
      const [subs, sessions] = await Promise.all([
        fetch('/api/subjects').then(r => r.json()),
        fetch('/api/sessions?days=365').then(r => r.json()),
      ])
      const blob = new Blob([JSON.stringify({ user, subjects: subs, sessions, progress, exportedAt: new Date().toISOString() }, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a'); a.href = url; a.download = 'studyforge-backup.json'; a.click()
      URL.revokeObjectURL(url)
      toast({ title: '📦 Exported!', description: 'Backup downloaded successfully' })
    } catch {
      toast({ title: '❌ Error', description: 'Export failed' })
    }
  }

  function requestNotifications() {
    if (!('Notification' in window)) { toast({ title: '❌ Not supported', description: 'Notifications not available' }); return }
    Notification.requestPermission().then(p => {
      if (p === 'granted') toast({ title: '🔔 Enabled!', description: 'You\'ll receive prayer & study reminders' })
      else toast({ title: '❌ Denied', description: 'Enable notifications in browser settings' })
    })
  }

  function installPWA() {
    toast({ title: '📱 Install App', description: 'Tap Share → Add to Home Screen (iOS) or use browser install button (Android/Chrome)' })
  }

  const SETTINGS = [
    { icon: Download, label: 'Export Data (JSON)', desc: 'Download your full study data', action: exportData, color: 'text-emerald-400' },
    { icon: Bell, label: 'Enable Notifications', desc: 'Prayer & study reminders', action: requestNotifications, color: 'text-sky-400' },
    { icon: Smartphone, label: 'Install as App (PWA)', desc: 'Add to your home screen', action: installPWA, color: 'text-brand-400' },
  ]

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-syne font-black text-2xl">Profile</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Your account & settings</p>
      </div>

      {/* Avatar & info */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl border border-border p-6 text-center">
        <div className="w-20 h-20 rounded-2xl gradient-brand mx-auto flex items-center justify-center font-syne font-black text-3xl text-white glow-brand mb-4">
          {initials}
        </div>
        <p className="font-syne font-black text-xl mb-0.5">{user?.name || 'Student'}</p>
        <p className="text-sm text-muted-foreground mb-4">{user?.email}</p>
        <div className="inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/25 text-yellow-400 px-3 py-1 rounded-full text-sm font-syne font-bold">
          ⚡ Level {level} &nbsp;•&nbsp; {xp} XP
        </div>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Study Days',  value: progress?.streak || 0,                      color: 'text-brand-400'  },
          { label: 'Hours Total', value: `${((progress?.totalMinutes || 0) / 60).toFixed(1)}h`, color: 'text-orange-400' },
          { label: 'Coins',       value: `🪙 ${progress?.coins || 0}`,              color: 'text-yellow-400' },
        ].map(({ label, value, color }) => (
          <div key={label} className="glass rounded-xl border border-border p-3 text-center">
            <p className={cn('font-syne font-black text-lg', color)}>{value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Account info */}
      <div className="glass rounded-2xl border border-border p-4 space-y-3">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground">Account</p>
        {[
          { label: 'Name',  value: user?.name  || '—' },
          { label: 'Email', value: user?.email || '—' },
          { label: 'Plan',  value: 'StudyForge Free' },
        ].map(({ label, value }) => (
          <div key={label} className="flex items-center justify-between py-1 border-b border-border last:border-0">
            <span className="text-sm text-muted-foreground">{label}</span>
            <span className="text-sm font-medium">{value}</span>
          </div>
        ))}
      </div>

      {/* Settings */}
      <div className="space-y-2">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-3">Settings</p>
        {SETTINGS.map(({ icon: Icon, label, desc, action, color }) => (
          <button key={label} onClick={action}
            className="w-full glass rounded-xl border border-border p-3.5 flex items-center gap-3 hover:bg-accent transition-all text-left">
            <div className={cn('p-2 rounded-lg bg-muted', color)}>
              <Icon size={16} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold">{label}</p>
              <p className="text-xs text-muted-foreground">{desc}</p>
            </div>
            <ChevronRight size={16} className="text-muted-foreground shrink-0" />
          </button>
        ))}
      </div>

      {/* Danger zone */}
      <div className="space-y-2">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground">Account Actions</p>
        <button onClick={() => signOut({ callbackUrl: '/auth/login' })}
          className="w-full flex items-center gap-3 p-3.5 rounded-xl glass border border-border hover:bg-accent transition-all text-left">
          <div className="p-2 rounded-lg bg-muted text-muted-foreground"><LogOut size={16} /></div>
          <div className="flex-1">
            <p className="text-sm font-semibold">Sign Out</p>
            <p className="text-xs text-muted-foreground">Sign out of your account</p>
          </div>
          <ChevronRight size={16} className="text-muted-foreground" />
        </button>
        <button
          onClick={() => { if (confirm('Delete account permanently? This cannot be undone.')) { toast({ title:'Coming Soon', description:'Contact support to delete your account' }) } }}
          className="w-full flex items-center gap-3 p-3.5 rounded-xl border border-red-500/20 bg-red-500/5 hover:bg-red-500/10 transition-all text-left">
          <div className="p-2 rounded-lg bg-red-500/10 text-red-400"><Trash2 size={16} /></div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-red-400">Delete Account</p>
            <p className="text-xs text-muted-foreground">Permanently remove all your data</p>
          </div>
          <ChevronRight size={16} className="text-red-400/50" />
        </button>
      </div>

      <p className="text-center text-xs text-muted-foreground pb-4">StudyForge 4.0 — AI Student OS &nbsp;•&nbsp; Made with ❤️</p>
    </div>
  )
}
