'use client'
// src/app/dashboard/achievements/page.tsx
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { cn, getLevelFromXP, getLevelProgress } from '@/lib/utils'
import { ACHIEVEMENTS, generateDailyQuests, generateWeeklyQuests } from '@/lib/achievements'

export default function AchievementsPage() {
  const [earnedIds, setEarnedIds] = useState<string[]>([])
  const [progress, setProgress] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/analytics').then(r => r.json()).then(d => {
      setEarnedIds(d.achievements || [])
      setProgress(d.progress)
      setLoading(false)
    })
  }, [])

  if (loading) return (
    <div className="flex items-center justify-center min-h-[50vh]">
      <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  const xp = progress?.xp || 0
  const level = getLevelFromXP(xp)
  const { pct, next } = getLevelProgress(xp)
  const coins = progress?.coins || 0
  const streak = progress?.streak || 0

  const dailyQuests = generateDailyQuests()
  const weeklyQuests = generateWeeklyQuests()

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-syne font-black text-2xl">Achievements</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Earn XP, level up, and unlock badges</p>
      </div>

      {/* Level card */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-brand-500/20 bg-gradient-to-br from-brand-500/10 to-cyan-500/5 p-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="font-syne font-black text-2xl text-yellow-400">Level {level}</p>
            <p className="text-sm text-muted-foreground mt-0.5">🪙 {coins} coins &nbsp;•&nbsp; 🔥 {streak} day streak</p>
          </div>
          <div className="w-14 h-14 rounded-2xl gradient-brand flex items-center justify-center font-syne font-black text-2xl text-white glow-brand">
            {level}
          </div>
        </div>
        <div className="h-2.5 bg-border rounded-full overflow-hidden mb-1">
          <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: 'easeOut' }}
            className="h-full rounded-full bg-gradient-to-r from-yellow-400 to-orange-400" />
        </div>
        <p className="text-xs text-muted-foreground font-mono">{xp} / {next} XP to next level</p>
      </motion.div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Earned', value: earnedIds.length, total: ACHIEVEMENTS.length, color: 'text-brand-400' },
          { label: 'Total XP', value: xp, color: 'text-yellow-400' },
          { label: 'Coins', value: coins, color: 'text-emerald-400' },
        ].map(({ label, value, total, color }) => (
          <div key={label} className="glass rounded-xl border border-border p-3 text-center">
            <p className={cn('font-syne font-black text-xl', color)}>
              {value}{total ? `/${total}` : ''}
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Badges grid */}
      <div>
        <h2 className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
          Badges <div className="flex-1 h-px bg-border" />
        </h2>
        <div className="grid grid-cols-3 gap-2">
          {ACHIEVEMENTS.map((ach, i) => {
            const earned = earnedIds.includes(ach.id)
            return (
              <motion.div key={ach.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.03 }}
                className={cn(
                  'glass rounded-2xl border p-3 text-center transition-all',
                  earned
                    ? 'border-yellow-500/40 bg-yellow-500/5'
                    : 'border-border opacity-40 grayscale',
                )}>
                <div className="text-3xl mb-1.5">{ach.icon}</div>
                <p className="font-syne font-black text-[11px] leading-tight mb-1">{ach.name}</p>
                <p className="text-[10px] text-muted-foreground leading-tight">{ach.desc}</p>
                <p className={cn('text-[10px] font-mono font-bold mt-1.5', earned ? 'text-yellow-400' : 'text-muted-foreground')}>
                  {earned ? '✓ ' : ''}+{ach.xp} XP
                </p>
              </motion.div>
            )
          })}
        </div>
      </div>

      {/* Daily Quests */}
      <div>
        <h2 className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
          Daily Quests <div className="flex-1 h-px bg-border" />
        </h2>
        <div className="space-y-2">
          {dailyQuests.map((q) => (
            <div key={q.id} className="glass rounded-xl border border-border p-3.5 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{q.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{q.desc}</p>
                <div className="h-1 bg-border rounded-full overflow-hidden mt-2">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: '0%' }} />
                </div>
              </div>
              <p className="font-syne font-black text-sm text-yellow-400 shrink-0">+{q.xp} XP</p>
            </div>
          ))}
        </div>
      </div>

      {/* Weekly Missions */}
      <div>
        <h2 className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
          Weekly Missions <div className="flex-1 h-px bg-border" />
        </h2>
        <div className="space-y-2">
          {weeklyQuests.map((q) => (
            <div key={q.id} className="glass rounded-xl border border-border p-3.5 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{q.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{q.desc}</p>
                <div className="h-1 bg-border rounded-full overflow-hidden mt-2">
                  <div className="h-full bg-brand-500 rounded-full" style={{ width: '0%' }} />
                </div>
              </div>
              <p className="font-syne font-black text-sm text-yellow-400 shrink-0">+{q.xp} XP</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
