// src/app/dashboard/page.tsx
import { auth } from '@/auth'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { DashboardClient } from '@/components/dashboard/DashboardClient'
import { getRiskLevel, getAIScore, PRAYER_NAMES } from '@/lib/utils'
import { getAIInsight } from '@/lib/ai-planner'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/auth/login')
  if (!session.user.onboardingDone) redirect('/onboarding')

  const userId = session.user.id

  const [user, subjects, progress, todayPrayerLog] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId } }),
    prisma.subject.findMany({
      where:   { userId },
      include: { chapters: true, topics: true },
      orderBy: { createdAt: 'asc' },
    }),
    prisma.userProgress.findUnique({ where: { userId } }),
    prisma.prayerLog.findFirst({
      where: {
        userId,
        date: (() => { const d = new Date(); d.setHours(0,0,0,0); return d })(),
      },
    }),
  ])

  // Compute overall risk
  const risks = subjects
    .filter((s) => s.examDate)
    .map((s) => getRiskLevel(s.totalChapters, s.chapters.filter((c) => c.completed).length, s.difficulty, s.examDate))
  const overallRisk = risks.includes('high') ? 'high' : risks.includes('mod') ? 'mod' : 'safe'

  const aiInsight = getAIInsight(subjects as any, overallRisk)

  // Prayer times from latest log
  const prayerTimes = {
    fajr:    todayPrayerLog?.fajrTime    || user?.wakeUpTime || '05:00',
    dhuhr:   todayPrayerLog?.dhuhrTime   || '12:30',
    asr:     todayPrayerLog?.asrTime     || '15:45',
    maghrib: todayPrayerLog?.maghribTime || '18:15',
    isha:    todayPrayerLog?.ishaTime    || '20:00',
    dur:     todayPrayerLog?.duration    || 20,
  }

  const prayersDone: Record<string, boolean> = {}
  if (todayPrayerLog) {
    PRAYER_NAMES.forEach((n) => { prayersDone[n] = !!(todayPrayerLog as any)[n] })
  }

  const subjectsData = subjects.map((s) => ({
    ...s,
    examDate:    s.examDate?.toISOString() || null,
    createdAt:   s.createdAt.toISOString(),
    updatedAt:   s.updatedAt.toISOString(),
    chapters:    s.chapters.map((c) => ({ ...c, completedAt: c.completedAt?.toISOString() || null, createdAt: c.createdAt.toISOString() })),
    topics:      s.topics.map((t) => ({ ...t })),
  }))

  return (
    <DashboardClient
      user={{ name: user?.name, college: user?.college, degree: user?.degree, semester: user?.semester }}
      subjects={subjectsData}
      progress={progress}
      overallRisk={overallRisk}
      aiInsight={aiInsight}
      prayerTimes={prayerTimes}
      prayersDone={prayersDone}
    />
  )
}
