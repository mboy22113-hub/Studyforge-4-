'use client'
// src/app/dashboard/analytics/page.tsx
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { cn, PRAYER_NAMES, PRAYER_DISPLAY } from '@/lib/utils'

const PRAYER_ICONS: Record<string,string> = { fajr:'🌙', dhuhr:'☀️', asr:'🌤', maghrib:'🌅', isha:'🌃' }
const COLORS = ['#7b5ea7','#00bcd4','#00c896','#ffc107','#ff7043','#81d4fa','#f06292']

export default function AnalyticsPage() {
  const [data, setData] = useState<any>(null)
  const [subjects, setSubjects] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      fetch('/api/analytics').then(r => r.json()),
      fetch('/api/subjects').then(r => r.json()),
    ]).then(([analytics, subs]) => {
      setData(analytics); setSubjects(subs); setLoading(false)
    })
  }, [])

  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" /></div>

  const hoursData = data?.hoursPerDay ? Object.entries(data.hoursPerDay).map(([date, hours]) => ({
    day: new Date(date).toLocaleDateString('en-US', { weekday:'short' }),
    hours: Math.round((hours as number) * 10) / 10,
  })) : []

  const pieData = subjects.map((s, i) => ({
    name: s.name, value: data?.subjectMins?.[s.id] || 0, color: s.color || COLORS[i % COLORS.length],
  })).filter(d => d.value > 0)

  const heatDays = Array.from({ length: 70 }, (_, i) => {
    const d = new Date(); d.setDate(d.getDate() - 69 + i)
    const ds = d.toISOString().split('T')[0]
    const hrs = (data?.hoursPerDay?.[ds] || 0) as number
    return { date: ds, level: hrs >= 4 ? 4 : hrs >= 2 ? 3 : hrs >= 1 ? 2 : hrs > 0 ? 1 : 0 }
  })

  const productivity = data?.productivityScore || 0
  const prodTip = productivity >= 80 ? '🌟 MashaAllah! Outstanding performance!'
    : productivity >= 60 ? '👍 Alhamdulillah! Keep up the great work!'
    : productivity >= 40 ? '💪 Bismillah — every session builds momentum!'
    : '🌱 Start with Fajr and build your study habit!'

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-syne font-black text-2xl">Analytics</h1>
        <p className="text-sm text-muted-foreground">Your academic performance at a glance</p>
      </div>

      {/* Study Hours Chart */}
      <motion.div initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} className="glass rounded-2xl border border-border p-4">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-4">Study Hours — Last 7 Days</p>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={hoursData} margin={{ top:0, right:0, bottom:0, left:-20 }}>
            <XAxis dataKey="day" tick={{ fill:'#7070a0', fontSize:11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill:'#7070a0', fontSize:11 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background:'#13132a', border:'1px solid rgba(255,255,255,0.08)', borderRadius:10, fontSize:12 }} cursor={{ fill:'rgba(123,94,167,0.1)' }} />
            <Bar dataKey="hours" fill="url(#barGrad)" radius={[4,4,0,0]} />
            <defs>
              <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#7b5ea7" /><stop offset="100%" stopColor="#00bcd4" />
              </linearGradient>
            </defs>
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Exam Readiness */}
      <motion.div initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.05 }} className="glass rounded-2xl border border-border p-4">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-4">Exam Readiness</p>
        <div className="space-y-3">
          {(data?.examReadiness || []).map((s: any) => (
            <div key={s.id}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium" style={{ color: s.color }}>{s.name}</span>
                <span className={cn('font-mono text-xs font-bold', s.risk==='high'?'text-red-400':s.risk==='mod'?'text-yellow-400':'text-emerald-400')}>{s.pct}%</span>
              </div>
              <div className="h-2 bg-border rounded-full overflow-hidden">
                <motion.div initial={{ width:0 }} animate={{ width:`${s.pct}%` }} transition={{ duration:.8, ease:'easeOut' }}
                  className="h-full rounded-full" style={{ background: s.color }} />
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Prayer Stats */}
      <motion.div initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.08 }} className="glass rounded-2xl border border-border p-4">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-4">Prayer Consistency</p>
        <div className="grid grid-cols-5 gap-2">
          {PRAYER_NAMES.map(n => (
            <div key={n} className="text-center bg-muted/50 rounded-xl p-2.5 border border-sky-500/10">
              <p className="text-sm mb-0.5">{PRAYER_ICONS[n]}</p>
              <p className="text-[10px] font-black uppercase text-sky-300">{PRAYER_DISPLAY[n]}</p>
              <p className="font-syne font-black text-lg text-foreground mt-0.5">{(data?.prayerStats?.[n] || 0)}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Subject Distribution Pie */}
      {pieData.length > 0 && (
        <motion.div initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.1 }} className="glass rounded-2xl border border-border p-4">
          <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-4">Subject Distribution</p>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="45%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip contentStyle={{ background:'#13132a', border:'1px solid rgba(255,255,255,0.08)', borderRadius:10, fontSize:12 }} formatter={(v: any) => [`${Math.round(v)} min`, 'Time']} />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize:11 }} />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>
      )}

      {/* Activity Heatmap */}
      <motion.div initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.12 }} className="glass rounded-2xl border border-border p-4">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-4">Activity Heatmap (70 Days)</p>
        <div className="grid grid-cols-10 gap-1">
          {heatDays.map((d, i) => (
            <div key={i} title={`${d.date}: ${d.level > 0 ? d.level + 'h+' : 'No study'}`}
              className={cn('aspect-square rounded-sm transition-all', d.level === 4 ? 'bg-brand-400' : d.level === 3 ? 'bg-brand-500/70' : d.level === 2 ? 'bg-brand-500/45' : d.level === 1 ? 'bg-brand-500/20' : 'bg-muted')} />
          ))}
        </div>
        <div className="flex items-center justify-end gap-1.5 mt-2">
          <span className="text-[10px] text-muted-foreground">Less</span>
          {[0,1,2,3,4].map(l => <div key={l} className={cn('w-3 h-3 rounded-sm', l===4?'bg-brand-400':l===3?'bg-brand-500/70':l===2?'bg-brand-500/45':l===1?'bg-brand-500/20':'bg-muted')} />)}
          <span className="text-[10px] text-muted-foreground">More</span>
        </div>
      </motion.div>

      {/* Productivity Score */}
      <motion.div initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.14 }} className="glass rounded-2xl border border-border p-4">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-3">Productivity Score</p>
        <div className="flex items-center gap-4">
          <div className="flex-1 h-3 bg-border rounded-full overflow-hidden">
            <motion.div initial={{ width:0 }} animate={{ width:`${productivity}%` }} transition={{ duration:1, ease:'easeOut' }}
              className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-400" />
          </div>
          <span className="font-syne font-black text-2xl text-emerald-400 min-w-[52px]">{productivity}%</span>
        </div>
        <p className="text-sm text-muted-foreground mt-2">{prodTip}</p>
        <div className="grid grid-cols-4 gap-2 mt-3">
          {[
            { label:'Tasks', value:`${data?.progress?.streak || 0}d`, color:'text-brand-400' },
            { label:'Focus', value:`${Math.round((data?.hoursPerDay ? Object.values(data.hoursPerDay).reduce((a: any, b: any) => a+b, 0) as number : 0) * 60)}m`, color:'text-orange-400' },
            { label:'Prayers', value:`${Object.values(data?.prayerStats || {}).reduce((a: any, b: any) => a+b, 0)}`, color:'text-sky-400' },
            { label:'XP', value:`${data?.progress?.xp || 0}`, color:'text-yellow-400' },
          ].map(({ label, value, color }) => (
            <div key={label} className="bg-muted/50 rounded-xl p-2 text-center border border-border">
              <p className={cn('font-syne font-black text-sm', color)}>{value}</p>
              <p className="text-[10px] text-muted-foreground">{label}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  )
}
