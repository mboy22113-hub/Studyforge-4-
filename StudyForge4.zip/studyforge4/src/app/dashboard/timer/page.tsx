'use client'
// src/app/dashboard/timer/page.tsx
import { useState, useEffect, useRef, useCallback } from 'react'
import { motion } from 'framer-motion'
import { cn, PRAYER_NAMES, PRAYER_DISPLAY } from '@/lib/utils'
import { Play, Pause, RotateCcw, CheckCircle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

const TECHNIQUES = {
  pomodoro:  { work:25,  brk:5,  long:15, sess:4, name:'🍅 Pomodoro',  desc:'25 min focus + 5 min break. After 4 sessions, a 15-min long break. Best for memorization and consistent progress.' },
  '5010':    { work:50,  brk:10, long:20, sess:3, name:'⚡ 50/10',     desc:'50 min deep work + 10 min break. Ideal for complex problems and hard subjects that need sustained concentration.' },
  deepwork:  { work:90,  brk:20, long:30, sess:2, name:'🧠 Deep Work', desc:'90 min uninterrupted focus. Maximum cognitive depth. Use in exam crisis mode for peak output.' },
} as const
type TechKey = keyof typeof TECHNIQUES

const CIRC = 2 * Math.PI * 78

export default function TimerPage() {
  const { toast } = useToast()
  const [tech, setTechKey] = useState<TechKey>('pomodoro')
  const [phase, setPhase] = useState<'work'|'brk'>('work')
  const [secs, setSecs] = useState(TECHNIQUES.pomodoro.work * 60)
  const [total, setTotal] = useState(TECHNIQUES.pomodoro.work * 60)
  const [running, setRunning] = useState(false)
  const [sessCount, setSessCount] = useState(0)
  const [dots, setDots] = useState<('done'|'brk')[]>([])
  const [focusToday, setFocusToday] = useState(0)
  const [subjects, setSubjects] = useState<any[]>([])
  const [selSub, setSelSub] = useState('')
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    fetch('/api/subjects').then(r => r.json()).then(d => { setSubjects(d); if (d[0]) setSelSub(d[0].id) })
    fetch('/api/sessions?days=1').then(r => r.json()).then(d => {
      const todayMins = (Array.isArray(d) ? d : []).reduce((s: number, s2: any) => s + (s2.durationMin || 0), 0)
      setFocusToday(todayMins)
    })
  }, [])

  function changeTech(t: TechKey) {
    if (running) return
    setTechKey(t); setPhase('work'); setSessCount(0); setDots([])
    const mins = TECHNIQUES[t].work * 60
    setSecs(mins); setTotal(mins); setRunning(false)
  }

  const phaseComplete = useCallback(async () => {
    setRunning(false)
    const tc = TECHNIQUES[tech]
    if (phase === 'work') {
      const wm = tc.work
      setSessCount(c => c + 1)
      setFocusToday(f => f + wm)
      setDots(d => [...d, 'done'])
      if ('Notification' in window && Notification.permission === 'granted') new Notification('⏱ Session Done!', { body: 'Take your break now.' })
      toast({ title:'⏱ Session Complete!', description:`+${wm} XP earned. Take a break!` })
      // Save to DB
      try {
        await fetch('/api/sessions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ subjectId: selSub || undefined, technique: tech, durationMin: wm, type: 'study' }),
        })
      } catch {}
      const isLong = (sessCount + 1) % tc.sess === 0
      const brkMins = (isLong ? tc.long : tc.brk) * 60
      setPhase('brk'); setSecs(brkMins); setTotal(brkMins)
    } else {
      setDots(d => [...d, 'brk'])
      if ('Notification' in window && Notification.permission === 'granted') new Notification('☕ Break Over!', { body: 'Time to focus again!' })
      toast({ title:'☕ Break Over!', description:'Back to work!' })
      const wm = TECHNIQUES[tech].work * 60
      setPhase('work'); setSecs(wm); setTotal(wm)
    }
  }, [tech, phase, sessCount, selSub, toast])

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSecs(s => {
          if (s <= 1) { phaseComplete(); return 0 }
          // Prayer warning check
          const now = new Date(); const nm = now.getHours() * 60 + now.getMinutes()
          if (s === 120) {
            PRAYER_NAMES.forEach(n => {
              const stored = localStorage.getItem(`prayer_time_${n}`) || ''
              if (stored) {
                const [ph, pm] = stored.split(':').map(Number)
                const pMins = ph * 60 + pm
                if (Math.abs(pMins - (nm + 2)) <= 1) toast({ title:'🕌 Prayer Soon!', description:`${PRAYER_DISPLAY[n]} in ~2 minutes` })
              }
            })
          }
          return s - 1
        })
      }, 1000)
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [running, phaseComplete, toast])

  function start() { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission(); setRunning(true) }
  function pause() { setRunning(false) }
  function reset() { setRunning(false); const wm = TECHNIQUES[tech].work * 60; setPhase('work'); setSecs(wm); setTotal(wm) }

  const progress = (total - secs) / total
  const offset = CIRC * (1 - progress)
  const mm = String(Math.floor(secs / 60)).padStart(2, '0')
  const ss = String(secs % 60).padStart(2, '0')
  const strokeColor = phase === 'brk' ? '#00c896' : '#7b5ea7'

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-syne font-black text-2xl">Focus Timer</h1>
          <p className="text-sm text-muted-foreground">Deep work mode — prayers auto-alert</p>
        </div>
      </div>

      {/* Technique selector */}
      <div className="flex gap-1.5 bg-muted rounded-xl p-1">
        {(Object.keys(TECHNIQUES) as TechKey[]).map(t => (
          <button key={t} onClick={() => changeTech(t)} disabled={running}
            className={cn('flex-1 py-2 rounded-lg text-xs font-syne font-black uppercase tracking-wide transition-all disabled:cursor-not-allowed',
              tech === t ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/30' : 'text-muted-foreground hover:text-foreground')}>
            {TECHNIQUES[t].name}
          </button>
        ))}
      </div>

      {/* Timer ring */}
      <div className="flex flex-col items-center gap-4 py-4">
        <p className={cn('font-syne font-black text-xs uppercase tracking-widest', phase === 'brk' ? 'text-emerald-400' : 'text-muted-foreground')}>
          {phase === 'work' ? 'FOCUS' : 'BREAK'}
        </p>

        <div className="relative w-48 h-48">
          <svg className="w-48 h-48 -rotate-90" viewBox="0 0 176 176">
            <circle cx="88" cy="88" r="78" fill="none" stroke="currentColor" strokeWidth="10" className="text-muted" />
            <circle cx="88" cy="88" r="78" fill="none" stroke={strokeColor} strokeWidth="10" strokeLinecap="round"
              strokeDasharray={CIRC} strokeDashoffset={offset}
              style={{ transition: 'stroke-dashoffset 1s linear, stroke 0.3s' }} />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center font-mono text-5xl font-semibold">
            {mm}:{ss}
          </div>
        </div>

        <div className="flex gap-3">
          {!running
            ? <button onClick={start} className="flex items-center gap-2 px-6 py-2.5 rounded-xl gradient-brand text-white font-syne font-bold text-sm glow-brand hover:opacity-90 transition-all"><Play size={16} /> Start</button>
            : <button onClick={pause} className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-muted border border-border text-sm font-semibold text-muted-foreground hover:text-foreground transition-all"><Pause size={16} /> Pause</button>
          }
          <button onClick={reset} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-muted border border-border text-sm font-semibold text-muted-foreground hover:text-foreground transition-all">
            <RotateCcw size={15} /> Reset
          </button>
        </div>

        <p className="text-sm text-muted-foreground">
          Session <span className="font-syne font-bold text-foreground">{sessCount + 1}</span>
          &nbsp;•&nbsp;
          <span className="font-mono">{focusToday}</span> min today
        </p>

        {/* Subject selector */}
        <div className="flex items-center gap-2.5 w-full max-w-xs bg-muted border border-border rounded-xl px-3.5 py-2.5">
          <span className="text-xs text-muted-foreground font-medium whitespace-nowrap">Studying:</span>
          <select value={selSub} onChange={e => setSelSub(e.target.value)}
            className="flex-1 bg-transparent border-none text-sm outline-none text-foreground">
            {subjects.map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>

        {/* Session dots */}
        <div className="flex flex-wrap gap-1.5 justify-center">
          {dots.map((type, i) => (
            <div key={i} className={cn('w-3 h-3 rounded-full', type === 'done' ? 'bg-brand-500' : 'bg-emerald-500')} />
          ))}
        </div>
      </div>

      {/* Technique info */}
      <div className="glass rounded-2xl border border-border p-4">
        <p className="font-syne font-black text-sm mb-2">{TECHNIQUES[tech].name}</p>
        <p className="text-sm text-muted-foreground leading-relaxed">{TECHNIQUES[tech].desc}</p>
      </div>

      {/* Today's sessions */}
      <div className="glass rounded-2xl border border-border p-4">
        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-2">Today</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="text-brand-400" size={16} />
            <span className="text-sm">{dots.filter(d => d === 'done').length} sessions completed</span>
          </div>
          <span className="font-mono text-sm text-brand-400">{focusToday} min</span>
        </div>
        <div className="mt-2 h-1.5 bg-border rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-brand-500 to-cyan-500 rounded-full transition-all"
            style={{ width: `${Math.min(100, (focusToday / 240) * 100)}%` }} />
        </div>
        <p className="text-xs text-muted-foreground mt-1">{focusToday}/240 min daily goal</p>
      </div>
    </div>
  )
}
