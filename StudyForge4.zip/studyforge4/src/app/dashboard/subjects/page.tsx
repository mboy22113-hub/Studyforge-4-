'use client'
// src/app/dashboard/subjects/page.tsx
import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { cn, daysUntil, formatDate, getRiskLevel, getAIScore } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { Upload, Eye, Trash2, Plus, ChevronDown, ChevronUp } from 'lucide-react'

export default function SubjectsPage() {
  const { toast } = useToast()
  const [subjects, setSubjects] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [localFiles, setLocalFiles] = useState<Record<string, { pdfs: any[]; photos: any[] }>>({})
  const pdfInputRef = useRef<HTMLInputElement>(null)
  const imgInputRef = useRef<HTMLInputElement>(null)
  const [pendingKey, setPendingKey] = useState('')

  useEffect(() => {
    fetch('/api/subjects').then(r => r.json()).then(d => { setSubjects(d); setLoading(false) })
    // Load local files from localStorage
    try {
      const stored = localStorage.getItem('sf40_files')
      if (stored) setLocalFiles(JSON.parse(stored))
    } catch {}
  }, [])

  function saveLocalFiles(files: Record<string, { pdfs: any[]; photos: any[] }>) {
    setLocalFiles(files)
    try { localStorage.setItem('sf40_files', JSON.stringify(files)) } catch { toast({ title:'⚠️ Storage full', description:'Remove some files' }) }
  }

  async function toggleChapter(subId: string, chapterId: string, completed: boolean) {
    setSubjects(subs => subs.map(s => s.id === subId ? {
      ...s, chapters: s.chapters.map((c: any) => c.id === chapterId ? { ...c, completed } : c),
    } : s))
    try {
      await fetch(`/api/subjects/${subId}/chapters/${chapterId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed }),
      })
      if (completed) toast({ title:'✅ Chapter Done!', description:'+30 XP earned' })
    } catch {}
  }

  function attachPDF(key: string) { setPendingKey(key); if (pdfInputRef.current) { pdfInputRef.current.value = ''; pdfInputRef.current.click() } }
  function attachPhoto(key: string) { setPendingKey(key); if (imgInputRef.current) { imgInputRef.current.value = ''; imgInputRef.current.click() } }

  function handlePDF(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return
    const existing = localFiles[pendingKey]?.pdfs || []
    if (existing.length >= 5) { toast({ title:'Limit', description:'Max 5 PDFs per lesson' }); return }
    const reader = new FileReader()
    reader.onload = (ev) => {
      const newFiles = { ...localFiles, [pendingKey]: { pdfs: [...existing, { name: file.name, data: ev.target?.result, date: new Date().toISOString().split('T')[0] }], photos: localFiles[pendingKey]?.photos || [] } }
      saveLocalFiles(newFiles)
      toast({ title:'📄 PDF Saved!', description: file.name })
    }
    reader.readAsDataURL(file)
  }

  function handlePhoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return
    const existing = localFiles[pendingKey]?.photos || []
    if (existing.length >= 9) { toast({ title:'Limit', description:'Max 9 photos per lesson' }); return }
    const reader = new FileReader()
    reader.onload = (ev) => {
      const newFiles = { ...localFiles, [pendingKey]: { pdfs: localFiles[pendingKey]?.pdfs || [], photos: [...existing, { name: file.name, data: ev.target?.result }] } }
      saveLocalFiles(newFiles)
      toast({ title:'📷 Photo Saved!', description: file.name })
    }
    reader.readAsDataURL(file)
  }

  function viewPDF(data: string, name: string) {
    const win = window.open(''); win?.document.write(`<iframe src="${data}" style="width:100%;height:100vh;border:none"></iframe>`)
  }
  function delPhoto(key: string, pi: number) {
    const photos = [...(localFiles[key]?.photos || [])]; photos.splice(pi, 1)
    saveLocalFiles({ ...localFiles, [key]: { ...localFiles[key], photos } })
  }
  function delPDF(key: string, pi: number) {
    const pdfs = [...(localFiles[key]?.pdfs || [])]; pdfs.splice(pi, 1)
    saveLocalFiles({ ...localFiles, [key]: { ...localFiles[key], pdfs } })
  }

  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" /></div>

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-syne font-black text-2xl">Subjects</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Tap a lesson to mark done • Attach PDFs & question photos</p>
      </div>

      <input ref={pdfInputRef} type="file" accept="application/pdf" className="hidden" onChange={handlePDF} />
      <input ref={imgInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />

      {subjects.map((sub, si) => {
        const comp = sub.chapters?.filter((c: any) => c.completed).length || 0
        const pct = sub.totalChapters > 0 ? Math.round(comp / sub.totalChapters * 100) : 0
        const risk = getRiskLevel(sub.totalChapters, comp, sub.difficulty, sub.examDate)
        const rColor = risk === 'high' ? '#ef5350' : risk === 'mod' ? '#ffc107' : '#00c896'
        const dTag = { easy:'dt-e', medium:'dt-m', hard:'dt-h' }[sub.difficulty as string] || ''
        const isOpen = expanded === sub.id
        const rScore = Math.round(getAIScore(sub.totalChapters, comp, sub.difficulty, sub.confidence, sub.previousMark || 60, sub.examDate) * 20)

        // Collect all photos for this subject
        let allPhotos: any[] = []
        for (let i = 0; i < sub.totalChapters; i++) {
          const k = `${sub.id}_${i}`
          ;(localFiles[k]?.photos || []).forEach((p: any, pi: number) => allPhotos.push({ ...p, ci: i, pi }))
        }

        return (
          <motion.div key={sub.id} initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay: si * 0.05 }}
            className="glass rounded-2xl border border-border overflow-hidden">
            {/* Subject header */}
            <div className="p-4 cursor-pointer" onClick={() => setExpanded(isOpen ? null : sub.id)}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-syne font-black text-base" style={{ color: sub.color }}>{sub.name}</span>
                    <span className={cn('text-[10px] px-1.5 py-0.5 rounded-lg font-bold',
                      sub.difficulty === 'easy' ? 'bg-emerald-500/15 text-emerald-400' : sub.difficulty === 'hard' ? 'bg-red-500/15 text-red-400' : 'bg-yellow-500/15 text-yellow-400')}>
                      {sub.difficulty}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    📅 {sub.examDate ? formatDate(sub.examDate) : 'No date'} &nbsp;•&nbsp;
                    <span style={{ color: rColor }}><strong>{daysUntil(sub.examDate)} days</strong></span> &nbsp;•&nbsp;
                    {comp}/{sub.totalChapters} done
                  </p>
                </div>
                <div className="flex items-center gap-2 ml-2">
                  <span className="font-mono text-sm font-bold" style={{ color: rColor }}>{pct}%</span>
                  {isOpen ? <ChevronUp size={16} className="text-muted-foreground" /> : <ChevronDown size={16} className="text-muted-foreground" />}
                </div>
              </div>
              {/* Progress bar */}
              <div className="h-1.5 bg-border rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: sub.color }} />
              </div>
              {/* Risk bar */}
              <div className="mt-1.5 h-1 bg-border/50 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(100, rScore)}%`, background: rColor }} />
              </div>
            </div>

            {/* Expanded content */}
            <AnimatePresence>
              {isOpen && (
                <motion.div initial={{ height:0, opacity:0 }} animate={{ height:'auto', opacity:1 }} exit={{ height:0, opacity:0 }} transition={{ duration:0.25 }}
                  className="overflow-hidden border-t border-border">
                  <div className="p-4 space-y-4">
                    {/* AI Rec */}
                    <div className="bg-brand-500/5 border border-brand-500/18 rounded-xl p-3 text-xs text-muted-foreground leading-relaxed">
                      <span className="text-brand-400 font-bold">🧠 AI: </span>
                      {risk === 'high' ? `URGENT — ${sub.totalChapters - comp} lessons remain with ${daysUntil(sub.examDate)} days. Skip non-essential content. Focus: ${sub.topics?.slice(0,2).map((t: any) => t.text).join(', ') || 'core chapters'}.`
                        : risk === 'mod' ? `Moderate risk. Complete ${Math.min(3, sub.totalChapters - comp)} lessons per session. Revise weak topics every 2 days.`
                        : `On track. ${sub.totalChapters - comp} lessons remaining. Target: ${sub.targetMark}%.`}
                    </div>

                    {/* Key Topics */}
                    {sub.topics?.length > 0 && (
                      <div>
                        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-2">⭐ Key Topics</p>
                        <div className="flex flex-wrap gap-1.5">
                          {sub.topics.map((t: any) => (
                            <span key={t.id} className="text-xs bg-brand-500/10 border border-brand-500/20 text-brand-400 px-2 py-0.5 rounded-lg">{t.text}</span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Chapters */}
                    <div>
                      <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-2">Lessons</p>
                      <div className="rounded-xl border border-border overflow-hidden">
                        {sub.chapters?.map((ch: any, ci: number) => {
                          const key = `${sub.id}_${ci}`
                          const hasPDF = (localFiles[key]?.pdfs || []).length > 0
                          const hasPhoto = (localFiles[key]?.photos || []).length > 0
                          return (
                            <div key={ch.id} className={cn('flex items-center gap-2.5 px-3 py-2.5 border-b border-border last:border-b-0 hover:bg-muted/50 transition-colors', ch.completed ? 'opacity-60' : '')}>
                              <button onClick={() => toggleChapter(sub.id, ch.id, !ch.completed)}
                                className={cn('w-4 h-4 rounded shrink-0 border-2 flex items-center justify-center text-[10px] font-bold transition-all',
                                  ch.completed ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-border hover:border-emerald-400')}>
                                {ch.completed ? '✓' : ''}
                              </button>
                              <div className={cn('w-1.5 h-1.5 rounded-full shrink-0', sub.topics?.length > 0 ? 'bg-red-400' : 'bg-emerald-400')} />
                              <span className={cn('flex-1 text-xs font-medium', ch.completed ? 'line-through text-muted-foreground' : '')}>Lesson {ch.number}</span>
                              <div className="flex gap-1.5">
                                <button onClick={() => attachPDF(key)}
                                  className={cn('text-[10px] px-1.5 py-0.5 rounded-md border font-bold transition-all',
                                    hasPDF ? 'border-emerald-500/40 text-emerald-400' : 'border-border text-muted-foreground hover:border-brand-400 hover:text-brand-400')}>
                                  📄{hasPDF ? ` ${localFiles[key].pdfs.length}` : ''}
                                </button>
                                <button onClick={() => attachPhoto(key)}
                                  className={cn('text-[10px] px-1.5 py-0.5 rounded-md border font-bold transition-all',
                                    hasPhoto ? 'border-emerald-500/40 text-emerald-400' : 'border-border text-muted-foreground hover:border-brand-400 hover:text-brand-400')}>
                                  📷{hasPhoto ? ` ${localFiles[key].photos.length}` : ''}
                                </button>
                                {hasPDF && (
                                  <button onClick={() => viewPDF(localFiles[key].pdfs[0].data, localFiles[key].pdfs[0].name)}
                                    className="text-[10px] px-1.5 py-0.5 rounded-md border border-cyan-500/30 text-cyan-400 font-bold hover:border-cyan-400 transition-all">
                                    <Eye size={10} />
                                  </button>
                                )}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </div>

                    {/* Question Photos */}
                    {allPhotos.length > 0 && (
                      <div>
                        <p className="font-syne font-black text-xs uppercase tracking-widest text-muted-foreground mb-2">📷 Question Photos ({allPhotos.length})</p>
                        <div className="grid grid-cols-3 gap-2">
                          {allPhotos.map((p, i) => (
                            <div key={i} className="aspect-square rounded-xl overflow-hidden relative border border-border">
                              <img src={p.data} alt="" className="w-full h-full object-cover cursor-pointer" onClick={() => { const w = window.open(''); w?.document.write(`<img src="${p.data}" style="max-width:100%;max-height:100vh"/>`) }} />
                              <button onClick={() => delPhoto(`${sub.id}_${p.ci}`, p.pi)}
                                className="absolute top-1 right-1 bg-black/70 text-white text-[10px] px-1 py-0.5 rounded-md hover:bg-red-500/80 transition-colors">
                                <Trash2 size={9} />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )
      })}

      {!subjects.length && !loading && (
        <div className="text-center py-16 text-muted-foreground">
          <p className="text-4xl mb-3">📚</p>
          <p className="font-syne font-bold text-lg mb-1">No subjects yet</p>
          <p className="text-sm">Complete onboarding to add your subjects</p>
        </div>
      )}
    </div>
  )
}
