'use client'
// src/app/dashboard/planner/page.tsx
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { cn, daysUntil, formatDate, getAIScore, getRiskLevel, PRAYER_NAMES, PRAYER_DISPLAY } from '@/lib/utils'
import { generatePlan } from '@/lib/ai-planner'
import { CalendarDays, Zap, AlertTriangle } from 'lucide-react'

const TABS = ['Daily', 'Weekly', 'Monthly', 'Crisis'] as const

export default function PlannerPage() {
  const [tab, setTab] = useState<typeof TABS[number]>('Daily')
  const [subjects, setSubjects] = useState<any[]>([])
  const [plan, setPlan] = useState<Record<string, any[]>>({})
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    async function load() {
      try {
        const [subRes, sessRes] = await Promise.all([
          fetch('/api/subjects'),
          fetch('/api/sessions?days=1'),
        ])
        const subs = await subRes.json()
        setSubjects(subs)
        // Generate plan client-side from subject data
        const generated = generatePlan({
          subjects: subs,
          prayers: { fajr:'05:00', dhuhr:'12:30', asr:'15:45', maghrib:'18:15', isha:'20:00', dur:20 },
          routine: { wake:'05:00', sleep:'23:00', col:'08:00', cole:'14:00', trav:1 },
          dailyHours: 4,
        })
        setPlan(generated)
      } catch (e) { console.error(e) }
      setLoading(false)
    }
    load()
  }, [])

  const risks = subjects.filter(s => s.examDate).map(s =>
    getRiskLevel(s.totalChapters, s.chapters?.filter((c: any) => c.completed).length || 0, s.difficulty, s.examDate))
  const overallRisk = risks.includes('high') ? 'high' : risks.includes('mod') ? 'mod' : 'safe'

  const RISK_SUMMARY = {
    safe: '✅ Balanced AI-optimised schedule — you\'re on track!',
    mod:  '⚡ Priority schedule active — weakest subjects first',
    high: '🚨 Crisis Mode — emergency revision strategy active',
  }

  function fmtDate(d: Date) {
    return d.toISOString().split('T')[0]
  }

  if (loading) return (
    <div className="flex items-center justify-center min-h-[50vh]">
      <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-syne font-black text-2xl">AI Planner</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{RISK_SUMMARY[overallRisk]}</p>
        </div>
        <CalendarDays className="text-brand-400" size={22} />
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 bg-muted rounded-xl p-1">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={cn('flex-1 py-2 rounded-lg text-xs font-syne font-black uppercase tracking-wide transition-all',
              tab === t ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/30' : 'text-muted-foreground hover:text-foreground')}>
            {t === 'Crisis' ? '🚨' : ''} {t}
          </button>
        ))}
      </div>

      {/* Daily View */}
      {tab === 'Daily' && (
        <div className="space-y-3">
          {Array.from({ length: 7 }, (_, i) => {
            const date = new Date(); date.setDate(date.getDate() + i)
            const ds = fmtDate(date)
            const tasks = plan[ds] || []
            const dayName = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : date.toLocaleDateString('en-US', { weekday: 'long' })
            return (
              <motion.div key={ds} initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay: i * 0.04 }}
                className="glass rounded-2xl border border-border p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="font-syne font-black text-sm">{dayName}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(date)}</p>
                  </div>
                  <span className="text-xs bg-muted px-2 py-1 rounded-lg font-mono">{tasks.filter(t => t.type !== 'prayer' && t.type !== 'sleep' && t.type !== 'wakeup').length} sessions</span>
                </div>
                {tasks.length ? (
                  <div className="space-y-1.5">
                    {tasks.map((t, ti) => {
                      const borderColor = t.type === 'prayer' ? 'border-sky-400' : t.type === 'revision' ? 'border-brand-400' : t.type === 'practice' ? 'border-orange-400' : t.type === 'sleep' ? 'border-cyan-500' : t.type === 'wakeup' ? 'border-yellow-400' : 'border-emerald-400'
                      const badge = t.type === 'revision' ? 'bg-brand-500/15 text-brand-400' : t.type === 'prayer' ? 'bg-sky-500/15 text-sky-400' : t.type === 'practice' ? 'bg-orange-500/15 text-orange-400' : t.type === 'sleep' ? 'bg-cyan-500/15 text-cyan-400' : t.type === 'wakeup' ? 'bg-yellow-500/15 text-yellow-400' : 'bg-emerald-500/15 text-emerald-400'
                      return (
                        <div key={ti} className={cn('flex items-center gap-2.5 px-3 py-2 bg-muted rounded-xl border-l-2', borderColor)}>
                          <span className="font-mono text-[10px] text-muted-foreground w-8 shrink-0">{t.duration}m</span>
                          <span className="flex-1 text-xs font-medium" style={{ color: t.subjectColor || undefined }}>{t.label}</span>
                          <span className={cn('text-[10px] px-1.5 py-0.5 rounded-md font-bold shrink-0', badge)}>{t.type}</span>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground text-center py-2">Rest day 🌿</p>
                )}
              </motion.div>
            )
          })}
        </div>
      )}

      {/* Weekly View */}
      {tab === 'Weekly' && (
        <div className="overflow-x-auto">
          <div className="flex gap-2 min-w-[520px] pb-2">
            {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((day, d) => {
              const date = new Date(); date.setDate(date.getDate() - date.getDay() + d)
              const ds = fmtDate(date)
              const tasks = (plan[ds] || []).filter(t => t.type !== 'prayer' && t.type !== 'sleep' && t.type !== 'wakeup')
              const isToday = ds === fmtDate(new Date())
              return (
                <div key={d} className={cn('flex-1 min-w-[70px] glass rounded-xl border p-2', isToday ? 'border-brand-500/40' : 'border-border')}>
                  <p className={cn('font-syne font-black text-[10px] uppercase text-center mb-1', isToday ? 'text-brand-400' : 'text-muted-foreground')}>{day}</p>
                  <p className="text-center text-xs text-muted-foreground mb-2">{date.getDate()}</p>
                  {tasks.length ? tasks.map((t, i) => (
                    <div key={i} className="h-1.5 rounded-full mb-1.5 opacity-80" style={{ background: t.subjectColor || '#7b5ea7' }} title={t.label} />
                  )) : <p className="text-[9px] text-muted-foreground text-center">—</p>}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Monthly View */}
      {tab === 'Monthly' && (
        <div>
          <p className="font-syne font-black text-sm mb-3">{new Date().toLocaleDateString('en-US', { month:'long', year:'numeric' })}</p>
          <div className="grid grid-cols-7 gap-0.5 mb-0.5">
            {['S','M','T','W','T','F','S'].map((d, i) => (
              <div key={i} className="text-center text-[10px] font-bold text-muted-foreground py-1">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-0.5">
            {(() => {
              const today = new Date(); const yr = today.getFullYear(); const mo = today.getMonth()
              const firstDay = new Date(yr, mo, 1).getDay()
              const daysInMonth = new Date(yr, mo + 1, 0).getDate()
              const cells = []
              for (let i = 0; i < firstDay; i++) cells.push(<div key={`e${i}`} />)
              for (let d = 1; d <= daysInMonth; d++) {
                const date = new Date(yr, mo, d)
                const ds = fmtDate(date)
                const hasTasks = !!(plan[ds]?.filter(t => t.type !== 'prayer' && t.type !== 'sleep' && t.type !== 'wakeup').length)
                const isToday = ds === fmtDate(today)
                const isPast = date < today && !isToday
                cells.push(
                  <div key={d} className={cn('aspect-square rounded-lg flex flex-col items-center justify-center text-xs font-medium relative transition-all',
                    isToday ? 'bg-brand-500/20 text-brand-400 font-bold border border-brand-500/30' : isPast ? 'bg-muted/30 text-muted-foreground/40' : 'bg-muted text-foreground hover:bg-accent')}>
                    {d}
                    {hasTasks && <div className="absolute bottom-0.5 w-1 h-1 rounded-full bg-brand-400" />}
                  </div>
                )
              }
              return cells
            })()}
          </div>
        </div>
      )}

      {/* Crisis View */}
      {tab === 'Crisis' && (
        <div className="space-y-3">
          <div className="flex items-center gap-2.5 p-3.5 rounded-xl bg-red-500/8 border border-red-500/25">
            <AlertTriangle className="text-red-400 shrink-0" size={18} />
            <p className="text-sm text-red-300">Subjects with exams within 14 days, sorted by AI risk score.</p>
          </div>
          {subjects.filter(s => s.examDate && daysUntil(s.examDate) >= 0 && daysUntil(s.examDate) <= 14)
            .sort((a, b) => {
              const as_ = getAIScore(a.totalChapters, a.chapters?.filter((c: any) => c.completed).length || 0, a.difficulty, a.confidence, a.previousMark || 60, a.examDate)
              const bs_ = getAIScore(b.totalChapters, b.chapters?.filter((c: any) => c.completed).length || 0, b.difficulty, b.confidence, b.previousMark || 60, b.examDate)
              return bs_ - as_
            })
            .map((sub, i) => {
              const comp = sub.chapters?.filter((c: any) => c.completed).length || 0
              const rem = sub.totalChapters - comp
              const days = daysUntil(sub.examDate)
              const topics = sub.topics?.slice(0, 3).map((t: any) => t.text).join(', ') || 'Core chapters'
              return (
                <motion.div key={sub.id} initial={{ opacity:0, x:-10 }} animate={{ opacity:1, x:0 }} transition={{ delay: i * 0.06 }}
                  className="glass rounded-2xl border border-red-500/20 p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="font-syne font-black text-sm" style={{ color: sub.color }}>{sub.name}</p>
                      <p className="text-xs text-muted-foreground">{days} days left &nbsp;•&nbsp; {rem} lessons remaining</p>
                    </div>
                    <span className="text-xs bg-red-500/15 text-red-400 px-2 py-0.5 rounded-lg font-bold border border-red-500/20">URGENT</span>
                  </div>
                  <div className="h-1.5 bg-border rounded-full overflow-hidden mb-2">
                    <div className="h-full rounded-full bg-gradient-to-r from-red-500 to-orange-400"
                      style={{ width: `${Math.round(comp / sub.totalChapters * 100)}%` }} />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-red-400 font-semibold">⚡ Focus:</span> {topics}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    <span className="font-semibold">Strategy:</span> Skip non-essential content. Aim for {Math.ceil(rem * 1.5)}h more study before exam.
                  </p>
                </motion.div>
              )
            })}
          {!subjects.filter(s => s.examDate && daysUntil(s.examDate) >= 0 && daysUntil(s.examDate) <= 14).length && (
            <div className="text-center py-10 text-muted-foreground">
              <p className="text-2xl mb-2">✅</p>
              <p className="text-sm">No exams in crisis zone (within 14 days)</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
