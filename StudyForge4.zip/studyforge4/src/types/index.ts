// src/types/index.ts
import type { Subject, Chapter, Topic, UserProgress, PrayerLog } from '@prisma/client'

export type RiskLevel = 'safe' | 'mod' | 'high'
export type Difficulty = 'easy' | 'medium' | 'hard'
export type Confidence = 'low' | 'med' | 'high'
export type StudyTechnique = 'pomodoro' | '5010' | 'deepwork'
export type PrayerName = 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'
export type TaskType = 'study' | 'revision' | 'practice' | 'prayer' | 'sleep' | 'wakeup'

export interface SubjectWithRelations extends Subject {
  chapters: Chapter[]
  topics: Topic[]
}

export interface PlanSession {
  id: string
  subjectId: string | null
  subjectName: string
  subjectColor: string
  type: TaskType
  duration: number
  label: string
  done: boolean
  chapter?: number
  prayerName?: PrayerName
}

export interface DayPlan {
  date: string
  sessions: PlanSession[]
}

export interface Achievement {
  id: string
  icon: string
  name: string
  desc: string
  xp: number
  coins: number
}

export interface Quest {
  id: string
  name: string
  desc: string
  target: number
  progress: number
  xp: number
  type: string
  done: boolean
}

export interface TechniqueConfig {
  work: number
  brk: number
  long: number
  sess: number
  name: string
  desc: string
}

export interface UserStats {
  xp: number
  level: number
  coins: number
  streak: number
  totalMinutes: number
}

export type { Subject, Chapter, Topic, UserProgress, PrayerLog }

// Extend NextAuth types
declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      name?: string | null
      email?: string | null
      image?: string | null
      onboardingDone: boolean
    }
  }
}
