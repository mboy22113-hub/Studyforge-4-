// src/lib/utils.ts
import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  })
}

export function daysUntil(date: Date | string | null): number {
  if (!date) return 999
  const target = new Date(date)
  target.setHours(0, 0, 0, 0)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return Math.round((target.getTime() - today.getTime()) / 86_400_000)
}

export function toHours(time: string): number {
  if (!time) return 0
  const [h, m] = time.split(':').map(Number)
  return h + (m || 0) / 60
}

export function getRiskLevel(
  chapters: number,
  completed: number,
  difficulty: string,
  examDate: Date | string | null,
): 'safe' | 'mod' | 'high' {
  const days = daysUntil(examDate)
  const remaining = chapters - completed
  const dw = difficulty === 'hard' ? 2.5 : difficulty === 'medium' ? 1.6 : 1
  if (days < 0) return 'safe'
  const score = (remaining * dw) / Math.max(1, days)
  if (score > 1.5 || days <= 5) return 'high'
  if (score > 0.7 || days <= 14) return 'mod'
  return 'safe'
}

export function getAIScore(
  chapters: number,
  completed: number,
  difficulty: string,
  confidence: string,
  prevMark: number,
  examDate: Date | string | null,
): number {
  const days = Math.max(1, daysUntil(examDate) || 999)
  const remaining = chapters - completed
  const dw = difficulty === 'hard' ? 2.5 : difficulty === 'medium' ? 1.6 : 1
  const cw = confidence === 'low' ? 2 : confidence === 'med' ? 1.4 : 1
  const pw = prevMark < 40 ? 2 : prevMark < 60 ? 1.5 : 1
  return (remaining * dw * cw * pw) / days
}

export const SUBJECT_COLORS = [
  '#7b5ea7', '#00bcd4', '#00c896', '#ffc107',
  '#ff7043', '#81d4fa', '#f06292', '#aed581',
  '#ce93d8', '#80deea',
]

export const PRAYER_NAMES = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'] as const
export const PRAYER_ICONS: Record<string, string> = {
  fajr: '🌙', dhuhr: '☀️', asr: '🌤', maghrib: '🌅', isha: '🌃',
}
export const PRAYER_DISPLAY: Record<string, string> = {
  fajr: 'Fajr', dhuhr: 'Dhuhr', asr: 'Asr', maghrib: 'Maghrib', isha: 'Isha',
}

export const XP_LEVELS = [0, 200, 500, 950, 1600, 2500, 3700, 5200, 7000, 9200, 12000]

export function getLevelFromXP(xp: number): number {
  let level = 1
  for (let i = XP_LEVELS.length - 1; i >= 0; i--) {
    if (xp >= XP_LEVELS[i]) { level = i + 1; break }
  }
  return level
}

export function getLevelProgress(xp: number): { pct: number; current: number; next: number } {
  const level = getLevelFromXP(xp)
  const current = XP_LEVELS[Math.min(level - 1, XP_LEVELS.length - 1)] || 0
  const next = XP_LEVELS[Math.min(level, XP_LEVELS.length - 1)] || 12000
  return { pct: Math.min(100, ((xp - current) / (next - current)) * 100), current, next }
}
