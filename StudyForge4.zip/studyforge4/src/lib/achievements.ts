// src/lib/achievements.ts
import type { Achievement } from '@/types'

export const ACHIEVEMENTS: Achievement[] = [
  { id: 'first_session', icon: '🎯', name: 'First Focus',     desc: 'Complete your first session',    xp: 50,   coins: 10  },
  { id: 'streak_3',      icon: '🔥', name: 'On Fire',         desc: '3-day study streak',              xp: 100,  coins: 25  },
  { id: 'streak_7',      icon: '⚡', name: 'Week Warrior',    desc: '7-day study streak',              xp: 250,  coins: 75  },
  { id: 'streak_30',     icon: '🏆', name: 'Legend',          desc: '30-day study streak',             xp: 1000, coins: 300 },
  { id: 'hours_5',       icon: '⏱', name: 'Dedicated',       desc: '5 hours total studied',           xp: 150,  coins: 40  },
  { id: 'hours_25',      icon: '📚', name: 'Scholar',         desc: '25 hours total studied',          xp: 500,  coins: 150 },
  { id: 'chapter_1',     icon: '📖', name: 'Chapter One',     desc: 'Complete first chapter',          xp: 75,   coins: 20  },
  { id: 'subject_done',  icon: '🎓', name: 'Completionist',   desc: 'Finish all chapters of a subject',xp: 400,  coins: 100 },
  { id: 'revision_5',    icon: '🔄', name: 'Revision Pro',    desc: '5 revision sessions done',        xp: 200,  coins: 60  },
  { id: 'fajr_study',    icon: '🌙', name: 'Fajr Scholar',    desc: 'Study right after Fajr prayer',   xp: 120,  coins: 30  },
  { id: 'all_prayers',   icon: '🕌', name: 'Prayer Keeper',   desc: 'Complete all 5 prayers in a day', xp: 200,  coins: 50  },
  { id: 'perfect_day',   icon: '✨', name: 'Perfect Day',     desc: 'Complete all tasks for a day',    xp: 150,  coins: 40  },
  { id: 'pdf_upload',    icon: '📄', name: 'PDF Master',      desc: 'Upload your first PDF',           xp: 60,   coins: 15  },
  { id: 'photo_upload',  icon: '📷', name: 'Visual Learner',  desc: 'Upload your first photo',         xp: 60,   coins: 15  },
  { id: 'crisis_study',  icon: '🚨', name: 'Crisis Survivor', desc: 'Study during exam crisis mode',   xp: 200,  coins: 50  },
  { id: 'early_bird',    icon: '🌅', name: 'Early Bird',      desc: 'Start studying before 7 AM',      xp: 100,  coins: 25  },
  { id: 'night_owl',     icon: '🦉', name: 'Night Owl',       desc: 'Study after 10 PM',               xp: 80,   coins: 20  },
  { id: 'coins_100',     icon: '🪙', name: 'Coin Collector',  desc: 'Earn 100 coins',                  xp: 50,   coins: 0   },
]

export function generateDailyQuests() {
  return [
    { id: 'dq_session', name: 'Study Session',   desc: 'Complete 1 focus session',     target: 1,  progress: 0, xp: 50,  type: 'sessions', done: false },
    { id: 'dq_focus',   name: '45-Min Focus',    desc: 'Accumulate 45 min of focus',   target: 45, progress: 0, xp: 75,  type: 'minutes',  done: false },
    { id: 'dq_task',    name: 'Task Crusher',    desc: 'Mark a study task done',        target: 1,  progress: 0, xp: 40,  type: 'tasks',    done: false },
    { id: 'dq_prayer',  name: 'Prayer Keeper',   desc: 'Log all 5 daily prayers',       target: 5,  progress: 0, xp: 100, type: 'prayers',  done: false },
  ]
}

export function generateWeeklyQuests() {
  return [
    { id: 'wq_hours',   name: 'Marathon Learner',     desc: 'Study 5+ hours this week',     target: 300, progress: 0, xp: 250, type: 'minutes',    done: false },
    { id: 'wq_days',    name: 'Consistent Scholar',   desc: 'Study 5 out of 7 days',        target: 5,   progress: 0, xp: 350, type: 'days',        done: false },
    { id: 'wq_chapters',name: 'Chapter Master',       desc: 'Complete 3 chapters',           target: 3,   progress: 0, xp: 300, type: 'chapters',    done: false },
    { id: 'wq_prayers', name: 'Prayer Champion',      desc: 'Complete all prayers for 5 days',target: 5, progress: 0, xp: 400, type: 'prayerDays',  done: false },
  ]
}
