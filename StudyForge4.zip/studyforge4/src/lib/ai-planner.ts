// src/lib/ai-planner.ts
import { getAIScore, PRAYER_DISPLAY, PRAYER_NAMES, toHours } from './utils'
import type { PlanSession, DayPlan, SubjectWithRelations } from '@/types'
import { v4 as uuid } from 'crypto'

function fmtDate(d: Date): string {
  return d.toISOString().split('T')[0]
}

function randomId() {
  return Math.random().toString(36).slice(2)
}

interface PlannerConfig {
  subjects: SubjectWithRelations[]
  prayers: {
    fajr: string; dhuhr: string; asr: string
    maghrib: string; isha: string; dur: number
  }
  routine: {
    wake: string; sleep: string; col: string; cole: string; trav: number
  }
  dailyHours: number
}

export function generatePlan(config: PlannerConfig): Record<string, PlanSession[]> {
  const { subjects, prayers, routine, dailyHours } = config
  const plan: Record<string, PlanSession[]> = {}

  const activeSubs = subjects.filter((s) => s.examDate)
  if (!activeSubs.length) return plan

  const today = new Date(); today.setHours(0, 0, 0, 0)
  const lastExam = activeSubs.reduce(
    (m, s) => { const d = new Date(s.examDate!); return d > m ? d : m },
    today,
  )
  const totalDays = Math.min(120, Math.ceil((lastExam.getTime() - today.getTime()) / 86_400_000) + 7)

  const awake = toHours(routine.sleep) > toHours(routine.wake)
    ? toHours(routine.sleep) - toHours(routine.wake)
    : 24 - toHours(routine.wake) + toHours(routine.sleep)
  const college = Math.max(0, toHours(routine.cole) - toHours(routine.col))
  const prayerTime = 5 * (prayers.dur || 20) / 60
  const overhead = 1.5 + (routine.trav || 1) + college + prayerTime
  const dailyMins = Math.max(90, Math.min(600, Math.min(awake - overhead, dailyHours) * 60))

  const tw = activeSubs.reduce((s, sub) => {
    const comp = sub.chapters.filter((c) => c.completed).length
    return s + getAIScore(sub.totalChapters, comp, sub.difficulty, sub.confidence, sub.previousMark || 60, sub.examDate)
  }, 0) || 1

  for (let d = 0; d < totalDays; d++) {
    const date = new Date(today); date.setDate(today.getDate() + d)
    const ds = fmtDate(date)
    const sessions: PlanSession[] = []
    let left = dailyMins

    // Wake-up block
    sessions.push({ id: randomId(), subjectId: null, subjectName: '', subjectColor: '', type: 'wakeup', duration: 30, done: false, label: `🌅 Wake Up & Morning Routine (${routine.wake})` })

    // Prayer blocks
    PRAYER_NAMES.forEach((pn) => {
      sessions.push({ id: randomId(), subjectId: null, subjectName: '', subjectColor: '', type: 'prayer', duration: prayers.dur || 20, done: false, label: `🕌 ${PRAYER_DISPLAY[pn]}`, prayerName: pn })
    })

    // Study blocks
    const sorted = [...activeSubs].sort((a, b) => {
      const ac = a.chapters.filter((c) => c.completed).length
      const bc = b.chapters.filter((c) => c.completed).length
      return getAIScore(b.totalChapters, bc, b.difficulty, b.confidence, b.previousMark || 60, b.examDate) -
             getAIScore(a.totalChapters, ac, a.difficulty, a.confidence, a.previousMark || 60, a.examDate)
    })

    sorted.forEach((sub) => {
      if (!sub.examDate) return
      const completed = sub.chapters.filter((c) => c.completed).length
      const dl = Math.round((new Date(sub.examDate).getTime() - date.getTime()) / 86_400_000)
      if (dl < 0) return

      // Final revision day
      if (fmtDate(new Date(sub.examDate)) === ds) {
        sessions.push({ id: randomId(), subjectId: sub.id, subjectName: sub.name, subjectColor: sub.color, type: 'revision', duration: 45, done: false, label: `🔄 FINAL REVISION: ${sub.name}` })
        return
      }

      const score = getAIScore(sub.totalChapters, completed, sub.difficulty, sub.confidence, sub.previousMark || 60, sub.examDate)
      const urg = dl <= 3 ? 3.5 : dl <= 7 ? 2.8 : dl <= 14 ? 2 : dl <= 30 ? 1.4 : 1
      const w = (score / tw) * urg
      const alloc = Math.round(Math.min(120, left * w))
      if (alloc < 15) return

      const isRevision = (dl <= 14 && d % 2 === 0)
      const isPractice = sub.topics.length > 0 && dl <= 21 && d % 3 === 0
      const type = isRevision ? 'revision' : isPractice ? 'practice' : 'study'
      const ch = Math.floor(d * (sub.totalChapters / Math.max(1, totalDays * 0.75))) % sub.totalChapters
      const topicHint = sub.topics.length && isRevision ? ` ★ ${sub.topics[d % sub.topics.length]?.text || ''}` : ''
      const label = type === 'revision'
        ? `🔄 Revision: ${sub.name}${topicHint}`
        : type === 'practice' ? `⭐ Practice: ${sub.name} (L${ch + 1})`
        : `📖 Study: ${sub.name} (L${ch + 1})`

      sessions.push({ id: randomId(), subjectId: sub.id, subjectName: sub.name, subjectColor: sub.color, type, duration: alloc, done: false, label, chapter: ch })
      left -= alloc
    })

    // Weekly review
    if (d > 0 && d % 7 === 0) {
      sorted.forEach((sub) => {
        sessions.push({ id: randomId(), subjectId: sub.id, subjectName: sub.name, subjectColor: sub.color, type: 'revision', duration: 20, done: false, label: `📝 Weekly Review: ${sub.name}` })
      })
    }

    // Sleep block
    sessions.push({ id: randomId(), subjectId: null, subjectName: '', subjectColor: '', type: 'sleep', duration: 0, done: false, label: `💤 Sleep Time (${routine.sleep})` })

    if (sessions.length > 3) plan[ds] = sessions
  }

  return plan
}

export function getAIInsight(subjects: SubjectWithRelations[], overallRisk: string): string {
  if (!subjects.length) return 'Add subjects and exam dates so the AI can analyze your plan.'
  const sorted = [...subjects].filter((s) => s.examDate).sort((a, b) => {
    const ac = a.chapters.filter((c) => c.completed).length
    const bc = b.chapters.filter((c) => c.completed).length
    return getAIScore(b.totalChapters, bc, b.difficulty, b.confidence, b.previousMark || 60, b.examDate) -
           getAIScore(a.totalChapters, ac, a.difficulty, a.confidence, a.previousMark || 60, a.examDate)
  })
  const top = sorted[0]
  if (!top) return 'Set exam dates to get AI recommendations.'
  if (overallRisk === 'high')
    return `🚨 <strong>Crisis Mode Active.</strong> <strong style="color:#ef5350">${top.name}</strong> has the highest risk score. Skip low-priority chapters. Focus only on key topics. Aim for ${Math.ceil((top.totalChapters - top.chapters.filter((c) => c.completed).length) * 1.5)} more hours immediately.`
  if (overallRisk === 'mod')
    return `⚡ <strong>Moderate pressure.</strong> Prioritize <strong>${top.name}</strong> today. Aim for ${Math.min(3, top.totalChapters - top.chapters.filter((c) => c.completed).length)} lessons before switching subjects.`
  return `✅ <strong>You're on track!</strong> Keep steady focus on <strong>${top.name}</strong>. Maintain your daily rhythm and revision schedule.`
}
